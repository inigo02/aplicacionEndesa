async function addCorpus()
{
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listLanguageModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
    var f= await getFileChooser("/addCorpus"); 
    divShowData.innerHTML = "<div><center> <b>Subir audios al modelo acustico<b></center><br><br></div>"+combo+"<br><br>"+f+"<br><br>";
}

async function listCorpus()
{
	
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listLanguageModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
    var obtenerList="/listCorpus";
	var deleteWord="/deleteCorpus";
    var boton = "<div><center><button class='submitForm' onclick='obtenerInfoResurces(\""+obtenerList+"\",\""+deleteWord+"\")'>Obtener lista de ficheros</button></center></div> ";
    divShowData.innerHTML = "<div><center> <b>Obtener ficheros que contiene el modelo de lenguaje seleccionado<b></center><br><br></div>"+combo+"<br>"+boton+"<br>";
}

async function listWords()
{
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listLanguageModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
	var obtenerList="/listWords";
	var deleteWord="/deleteWord";
    var boton = "<div><center><button class='submitForm' onclick='obtenerInfoResurces(\""+obtenerList+"\",\""+deleteWord+"\")'>Obtener lista de palabras</button></center></div> ";
    divShowData.innerHTML = "<div><center> <b>Obtener palabras añadidas al modelo de lenguaje seleccionado<b></center><br><br></div>"+combo+"<br>"+boton+"<br>";
}
