
async function words()
{
	var respuesta= getForm()
	var modelos = await obtenerModelos("/listLanguageModels");
	var combo = await crearCombo(modelos);
	combo = "<center>"+combo+"</center>";
	var divShowData = document.getElementById('resultados');
	divShowData.innerHTML = "<div><center> <b>Subir palabras al modelo de lenguaje<b></center><br><br></div>"+combo+"<br><br>"+respuesta;
}

function getForm()
{
	var resultado="<div id='wordEntry'>"
				+ "	<div>"
				+ "		<div id='inputFormRow'>"
				+ "			<div>"
				+ "				<p>Introduce el nombre de la palabra:<p>"
				+ "				<input type='text' name='wordName' class='inputText' placeholder='Name of the word' autocomplete='off' required>"
				+ "			</div>"
				+ "			<div>"
				+ "				<p>Introduce cómo se visualizará la palabra:<p>"
				+ "				<input type='text' name='displayAs' class='inputText' placeholder='Display as' autocomplete='off' required>"
				+ "			</div>"
				+ "			<div id='fileChooserAdd'>"
				+ "			<p>Introduce cómo suena la palabra (maximo 5 formas):<p>"
				+ "				<div>"
				+ "					<input type='text' name='soundsAs' class='inputText' placeholder='Word sounds as' autocomplete='off' required>"
				+ "					<button class ='buttonAdd' type='button' class='btn btn-info' onclick='addSoundAs()'>+</button>"
				+ "				</div>"
				+ "			</div>"
				+ "		</div>"
				+ "		<button class='submitForm' onclick='addWordToModel()'> Crear palabra</button> "
				+ "	</div>"
				+ "</div>		";
	return resultado.trim();
}

function addSoundAs(){   
   if(document.getElementsByClassName('inputText').length<7){
		var html ='<div><input type="text" name="soundsAs" class="inputText" placeholder="Word sounds as" autocomplete="off" required>';
		html += '<button type="button" class ="buttonDelete" onclick="deleteSoundAs(this)">-</button>';
		html += '</div>';
		
		var ab=[];
		var soundsAs = document.querySelectorAll('input[name="soundsAs"]');
		soundsAs.forEach(curr => {
	  		 ab.push(curr.value);
			});
		document.getElementById('fileChooserAdd').innerHTML+=html;
		soundsAs = document.querySelectorAll('input[name="soundsAs"]');
		for(var i=0; i<ab.length; i++)
			soundsAs[i].value=ab[i];		
	}
	else{
		alert("como maximo se pueden introducir 5 valores en el campo sound as");
		return true;
	}
	
}
	
function deleteSoundAs(elementoAborrar){
	elementoAborrar.parentElement.remove();
}

function addWordToModel()
{
	
	var modelId = document.querySelector('select[name="comboBox"]').value;
	var wordName = document.querySelector('input[name="wordName"]').value;
	var displayAs = document.querySelector('input[name="displayAs"]').value;
	var soundsAs = document.querySelectorAll('input[name="soundsAs"]');
	
	var isCompleted = isAllComplete(modelId, wordName, displayAs, soundsAs);
	
	if(!isCompleted)
	{
		alert('rellene todos los campos');
		return;
	}
	var SoundsAsList="";
	soundsAs.forEach(curr => {
		SoundsAsList += curr.value+"--#--";
		});
		
	var form_data = new FormData();                  
    form_data.append('modelID', modelId);
	form_data.append('wordName', wordName);
	form_data.append('displayAs', displayAs);
	form_data.append('soundsAs', SoundsAsList);
	var response = "/addWord";
	crearPalabrasEnModelos(form_data, response);
	clearAll();
}

function isAllComplete(modelId, wordName, displayAs, soundsAs)
{
	
	if(modelId=="" || wordName=="" || displayAs=="")
		return false;
		
	
	soundsAs.forEach(curr => {
  		if(curr.value=="")
  			return false;
		});
	return true;
}
function clearAll()
{	
	//borrar textFields añadidos con el boton add
	var deleteComps = document.querySelectorAll('.buttonDelete');
	deleteComps.forEach(curr => {
		deleteSoundAs(curr);
		});
	//borrar el texto escrito
	var allcomp = document.querySelectorAll('.inputText')
	allcomp.forEach(curr => {
		if(curr.getAttribute('name')!="comboBox")
			curr.value="";
		});
}

async function crearPalabrasEnModelos(form_data, response)
{
	await $.ajax({
		
		url: response, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',
		success: function(java_response){
	   		console.log(java_response);
	   		alert(java_response);
		}
	 });	
		
}




