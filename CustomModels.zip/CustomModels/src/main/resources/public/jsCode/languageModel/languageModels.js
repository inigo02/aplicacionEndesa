	
/* VER MODELOS*/
async function verModelos (){    		   	
	document.getElementById('resultados').innerHTML="";
	var jsonRespuesta = await obtenerInfoModelos("/listLanguageModels");
	var urlDeleteModel="/deleteLanguageModel";
	var funcionDelete="deleteModel";
	tableFromJson(jsonRespuesta,urlDeleteModel,funcionDelete);
	}
	
	
/* CREAR MODELO*/
	
function createLanguageModel()
{
	var response =  "/addLanguageModel";
	var respuesta= getFormModelCreation(response)
	var divShowData = document.getElementById('resultados');
	    divShowData.innerHTML = "<div><center> <b>Crear Modelo<b></center><br><br></div>"+respuesta;
}



async function entrenarModeloLenguaje()
{
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listLanguageModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
	var urlEjecucion="/trainLanguageModel";
    var boton = "<div><center><button class='submitForm' onclick='entrenarModelo(\""+urlEjecucion+"\")'>Entrenar modelo de lenguaje</button></center></div> ";

    divShowData.innerHTML = "<div><center> <b>Subir audios al modelo acustico<b></center><br><br></div>"+combo+"<br><br>"+boton+"<br><br>";

}
