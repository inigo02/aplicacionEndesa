	
/* VER MODELOS*/
async function verModelos (){    		   	
	document.getElementById('resultados').innerHTML="";
	var jsonRespuesta = await obtenerInfoModelos("/listLanguageModels");
	var urlDeleteModel="/deleteLanguageModel";
	var funcionDelete="deleteModel";
	tableFromJson(jsonRespuesta,urlDeleteModel,funcionDelete);
	}
	
	
/* CREAR MODELO*/
	
function createLanguageModel()
{
	var respuesta= getFormModel()
	var divShowData = document.getElementById('resultados');
	    divShowData.innerHTML = "<div><center> <b>Crear Modelo<b></center><br><br></div>"+respuesta;
}

function getFormModel()
{
	var baseModels=["es-ES_NarrowbandModel", "es-ES_BroadbandModel", "es-ES_Telephony", "es-ES_Multimedia"];
	var resultado="<div id='wordEntry'>"
				+ "		<div id='inputFormRow'>"
				+ "			<div>"
				+ "				<p>Introduce nombre del modelo:<p>"
				+ "				<input type='text' name='nombreModelo' class='inputText' placeholder='Name of the word' autocomplete='off' required>"
				+ "			</div>"
				+ "			<div>"
				+ "				<p>Introduce descripcion del modelo:<p>"
				+ "				<input type='text' name='descripcionModelo' class='inputText' placeholder='Descripcion del modelo' autocomplete='off' required>"
				+ "			</div>"
				+ "			<p>Introduce cel base model de la palabra<p>"
				+ "			<div>"
				+ 				crearCombo(baseModels)
				+ "			</div>"
				+ "			<div>"
				+ "		<button class='submitForm' onclick='executeAcousticModelCreation()'> Crear Modelo</button> "
				+ "		</div>"
				+ "	</div>"
				+ "</div>		";
	return resultado.trim();
}

function executeAcousticModelCreation()
{
	var modelName = document.querySelector('input[name="nombreModelo"]').value;
	var modelDesc = document.querySelector('input[name="descripcionModelo"]').value;
	var baseModel = document.querySelector('select[name="comboBox"]').value;
	
	if(modelName=="" )
	{
		alert('rellene el campo de modelId');
		return;
	}
	
	var form_data = new FormData();                  
    form_data.append('name', modelName);
	form_data.append('description', modelDesc);
	form_data.append('baseModel', baseModel);
	var response =  "/addLanguageModel";
	crearModeloPersonalizado(form_data,response);
	clearAllModels();
}