async function getFileChooser(response)
{
	
	var result ="<center><input type='file' name='audiofile' id='audiofile' onchange='addFiles(\"" + response + "\")' style='display: none;' multiple>"
				+"<label for='audiofile'>"
				+"	<svg xmlns='http://www.w3.org/2000/svg' width='100%' height='20' viewBox='0 0 20 17'><path d='M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z'></path>"
				+"</svg> "
				+"	<span>Seleccionar archivo…</span>"
				+"	</label> </center>";
	
	return result.trim();

}

async function addFiles(response){
	var modelId = document.querySelector('select[name="comboBox"]').value;
	var archivos_de_audio = $('#audiofile').prop('files');
	var divShowData = document.getElementById('resultados');
	for(var i=0;i<archivos_de_audio.length;i++)
	{
		var archivo_audio = archivos_de_audio[i];
		var form_data = new FormData();                  
		form_data.append('archivo_audio', archivo_audio);
		form_data.append('modelID', modelId);
		await $.ajax({
			url: response, 
			dataType: 'text',  
			cache: false,
			contentType: false,
			processData: false,
			data: form_data,                         
			type: 'post',
			success: function(java_response){
		   		console.log(java_response);
		   		divShowData.innerHTML+="<center>"+java_response+"<br></center>";	    				
			}
    	});
	}
}

 function crearCombo(opciones)
{
	var respuesta = "<select class='inputText' name='comboBox'>";
	for (let i = 0; i < opciones.length; i++) 
		respuesta+="<option>"+opciones[i]+"</option>";			
	respuesta+= "</select>";
	return respuesta;
}
	
async function obtenerInfoResurces(urlCodigo, urlDelete)
{
	var modelId = document.querySelector('select[name="comboBox"]').value;
	var form_data = new FormData();    
	form_data.append('modelID', modelId);
	var resultado="";
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
        	resultado = eval(text);
        	tableFromJson(resultado, urlDelete,"eliminarElemento");
        },
        error: function (jqXHR) {
            resultado ='Error: ' + jqXHR.status;
        }
	});
	return resultado;
}
	
async function eliminarElemento(urlId)
{
	var selectedCheckBoxes = getSelectedCheckbox();
	for(var i=0; i<selectedCheckBoxes.length;i++)
	{
		await eliminarDelModelo(urlId, selectedCheckBoxes[i]);
	}
	alert("Elementos eliminados");
}

function getSelectedCheckbox()
{
	var selectedCheckBoxes=[];
	var checkBoxes = document.querySelectorAll(".check");
	checkBoxes.forEach(curr => {
     if (curr.checked)
     {
		var tableRow=curr.parentElement.parentElement;
		selectedCheckBoxes.push(tableRow);
	}         
	});
	return selectedCheckBoxes;
}

function encontrarColumnaName(tableRow)
{
	var columnas = tableRow.parentElement.children[0].children;
	var indexColName=0;
	for(indexColName=0; indexColName<columnas.length; indexColName++)
	{
		var nombreColumna=columnas[indexColName].innerHTML;
		if(nombreColumna=="customization_id")
			break;
	  	else if(nombreColumna=="name" || nombreColumna=="word")
	    	break;
	}
	return indexColName;
}

async function eliminarDelModelo(urlCodigo, selectedRow, modelId)
{
	var indexColumnName = encontrarColumnaName(selectedRow);
	var nombreElemento=selectedRow.children[indexColumnName].innerHTML
	var form_data = new FormData();    
	form_data.append('modelID', modelId);
	form_data.append('nombreElemento', nombreElemento);
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
        	console.log(text);
        	selectedRow.remove();
        },
        error: function (jqXHR) {
            console.log('Error: ' + jqXHR.status);
        }
	});

}
