function tableFromJson(jsonRespuesta, urlDelete, functionName) 
{
     // Extract value from table header. 
    var col = [];
    col.push("Eliminar");
    for (var i = 0; i < jsonRespuesta.length; i++) {
        for (var key in jsonRespuesta[i]) {
            if (col.indexOf(key) === -1) {
                col.push(key);
            }
        }
    }

    // Create a table.
    var table = document.createElement("table");
	table.className="table";
	
    // Create table header row using the extracted headers above.
    var tr = table.insertRow(-1);                   // table row.
	tr.className="row green";
    for (var i = 0; i < col.length; i++) {
        var th = document.createElement("th");      // table header.
        th.innerHTML = col[i];
        tr.appendChild(th);
    }

    // add json data to the table as rows.
    for (var i = 0; i < jsonRespuesta.length; i++) {

        tr = table.insertRow(-1);
        tr.className="row";

        for (var j = 0; j < col.length; j++) {
            var tabCell = tr.insertCell(-1);
            if(j==0)
            	tabCell.innerHTML = " <input type='checkbox' class='check'>";
            else
            	tabCell.innerHTML = jsonRespuesta[i][col[j]];
        }
    }

    // Now, add the newly created table with json data, to a container.
    var divShowData = document.getElementById('resultados');
    var selectedModelID = functionName=="deleteModel"?"":document.querySelector('select[name="comboBox"]').value; 
    
    
    divShowData.appendChild(table);
    
    var div = document.createElement("div");
    div.className="contenidoTabla";
  
    var boton = "<div><center><button class='submitForm' onclick='"+functionName+"(\""+urlDelete+"\",\""+selectedModelID+"\")'>Eliminar Elemento</button></center></div> ";
	div.appendChild(table);
	divShowData.innerHTML="";
	divShowData.appendChild(div);
    divShowData.innerHTML += boton;
}