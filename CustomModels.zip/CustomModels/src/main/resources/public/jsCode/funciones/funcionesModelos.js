
async function obtenerInfoModelos(urlCodigo)
{
	var resultado="";
	await $.ajax({
		type: 'POST',
		url: urlCodigo,                    
		success: function(text) {         
        	resultado = eval(text);
        	console.log(resultado)
        },
        error: function (jqXHR) {
			console.log("error "+ jqXHR.status)
            resultado ='Error: ' + jqXHR.status;
        }
	});
	return resultado;
}

async function crearModeloPersonalizado(form_data, response)
{
	var divShowData = document.getElementById('resultados');
	await $.ajax({
		url: response, // point to server-side PHP script 
		dataType: 'text',  // what to expect back from the PHP script, if anything
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',
		success: function(java_response){
	   		console.log(java_response);
	   		divShowData.innerHTML+="<center>"+java_response+"<br></center>";
		}
	 });		
}

function clearAllModels()
{	
	//borrar el texto escrito en los textFields
	var allcomp = document.querySelectorAll('.inputText')
	allcomp.forEach(curr => {
		curr.value="";
		});
}

async function obtenerModelos(urlCodigo)
{
	var infoModelos = await obtenerInfoModelos(urlCodigo);
	var modelos = [];
    for (var i = 0; i < infoModelos.length; i++) {
		modelos.push(infoModelos[i]["customization_id"]);     
    }
    return modelos;
}

async function deleteModel(urlDelete,notUsedAttribute)
{
	let text = "Estas seguro que quieres borrar el modelo?\nSi lo borras no podras recuperarlo.";
	 if (confirm(text) == true) {
		var selectedCheckBoxes = getSelectedCheckbox();
		for(var i=0; i<selectedCheckBoxes.length;i++)
		{
			await eliminarModeloAjax(urlDelete, selectedCheckBoxes[i]);
		}
		alert("Modelo eliminado");
	} 
}

async function eliminarModeloAjax(urlCodigo, selectedRow)
{
	var indexColumnName = encontrarColumnaName(selectedRow);
	var nombreElemento=selectedRow.children[indexColumnName].innerHTML
	var form_data = new FormData();    
	form_data.append('modelID', nombreElemento);
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
	    	console.log(text);
	    	selectedRow.remove();
	    },
	    error: function (jqXHR) {
	        console.log('Error: ' + jqXHR.status);
	    }
	});
}

async function entrenarModelo(urlCodigo)
{
	var modelId = document.querySelector('select[name="comboBox"]').value;
	var form_data = new FormData();    
	form_data.append('modelID', modelId);
	console.log("train "+modelId)
	console.log("train "+urlCodigo)
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
	    	console.log(text);
	    	var divShowData = document.getElementById('resultados');
	    	divShowData.innerHTML+=text;

	    },
	    error: function (jqXHR) {
	        console.log('Error: ' + jqXHR.status);
	    }
	});
}

async function makeAcousticModelTrain(urlCodigo)
{
	console.log("barruan");
	var acousticId="", languageId="";

	var modelId = document.querySelectorAll('select[name="comboBox"]').forEach(
		
		element => {
			if(element.id=="comboAcoustic")
				acousticId = element.value;
			else if(element.id=="comboLenguaje")
				languageId = element.value;
			}
	);
	
	var form_data = new FormData();    
	form_data.append('acousticModelID', acousticId);
	form_data.append('languageModelID', languageId);
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
	    	console.log(text);
	    	var divShowData = document.getElementById('resultados');
	    	divShowData.innerHTML+=text;
	    },
	    error: function (jqXHR) {
	        console.log('Error: ' + jqXHR.status);
	    }
	});
}


function getFormModelCreation(response)
{
	var baseModels=["es-ES_NarrowbandModel", "es-ES_BroadbandModel", "es-ES_Telephony", "es-ES_Multimedia"];
	var resultado="<div id='wordEntry'>"
				+ "		<div id='inputFormRow'>"
				+ "			<div>"
				+ "				<p>Introduce nombre del modelo:<p>"
				+ "				<input type='text' name='nombreModelo' class='inputText' placeholder='Name of the word' autocomplete='off' required>"
				+ "			</div>"
				+ "			<div>"
				+ "				<p>Introduce descripcion del modelo:<p>"
				+ "				<input type='text' name='descripcionModelo' class='inputText' placeholder='Descripcion del modelo' autocomplete='off' required>"
				+ "			</div>"
				+ "			<p>Introduce cel base model de la palabra<p>"
				+ "			<div>"
				+ 				crearCombo(baseModels)
				+ "			</div>"
				+ "			<div>"
				+ "		<button class='submitForm' onclick='executeModelCreation(\""+response+"\")'> Crear Modelo</button> "
				+ "		</div>"
				+ "	</div>"
				+ "</div>		";
	return resultado.trim();
}

function executeModelCreation(response)
{
	console.log(response)
	var modelName = document.querySelector('input[name="nombreModelo"]').value;
	var modelDesc = document.querySelector('input[name="descripcionModelo"]').value;
	var baseModel = document.querySelector('select[name="comboBox"]').value;
	
	if(modelName=="" )
	{
		alert('rellene el campo de modelId');
		return;
	}
	
	var form_data = new FormData();                  
    form_data.append('name', modelName);
	form_data.append('description', modelDesc);
	form_data.append('baseModel', baseModel);

	crearModeloPersonalizado(form_data,response);
	clearAllModels();
}



