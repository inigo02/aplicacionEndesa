
async function obtenerInfoModelos(urlCodigo)
{
	var resultado="";
	await $.ajax({
		type: 'POST',
		url: urlCodigo,                    
		success: function(text) {         
        	resultado = eval(text);
        	console.log(resultado)
        },
        error: function (jqXHR) {
			console.log("error "+ jqXHR.status)
            resultado ='Error: ' + jqXHR.status;
        }
	});
	return resultado;
}

async function crearModeloPersonalizado(form_data, response)
{
	var divShowData = document.getElementById('resultados');
	await $.ajax({
		url: response, // point to server-side PHP script 
		dataType: 'text',  // what to expect back from the PHP script, if anything
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',
		success: function(java_response){
	   		console.log(java_response);
	   		divShowData.innerHTML+="<center>"+java_response+"<br></center>";
		}
	 });		
}

function clearAllModels()
{	
	//borrar el texto escrito en los textFields
	var allcomp = document.querySelectorAll('.inputText')
	allcomp.forEach(curr => {
		curr.value="";
		});
}

async function obtenerModelos(urlCodigo)
{
	var infoModelos = await obtenerInfoModelos(urlCodigo);
	var modelos = [];
    for (var i = 0; i < infoModelos.length; i++) {
		modelos.push(infoModelos[i]["customization_id"]);     
    }
    return modelos;
}

async function deleteModel(urlDelete,notUsedAttribute)
{
	let text = "Estas seguro que quieres borrar el modelo?\nSi lo borras no podras recuperarlo.";
	 if (confirm(text) == true) {
		var selectedCheckBoxes = getSelectedCheckbox();
		for(var i=0; i<selectedCheckBoxes.length;i++)
		{
			await eliminarModeloAjax(urlDelete, selectedCheckBoxes[i]);
		}
		alert("Modelo eliminado");
	} 
}

async function eliminarModeloAjax(urlCodigo, selectedRow)
{
	var indexColumnName = encontrarColumnaName(selectedRow);
	var nombreElemento=selectedRow.children[indexColumnName].innerHTML
	var form_data = new FormData();    
	form_data.append('modelID', nombreElemento);
	await $.ajax({
		url: urlCodigo, 
		dataType: 'text',  
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,                         
		type: 'post',                   
		success: function(text) {         
	    	console.log(text);
	    	selectedRow.remove();
	    },
	    error: function (jqXHR) {
	        console.log('Error: ' + jqXHR.status);
	    }
	});
}
