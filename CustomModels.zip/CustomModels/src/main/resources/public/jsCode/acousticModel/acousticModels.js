
async function verModelosAcusticos (){   
	document.getElementById('resultados').innerHTML="";
	var jsonRespuesta = await obtenerInfoModelos("/listAcousticModels");
	var urlDeleteModel="/deleteAcousticModel";
	var funcionDelete="deleteModel";
	tableFromJson(jsonRespuesta,urlDeleteModel,funcionDelete);
	}
	
	
function createAcousticModel()
{
	var response = "/addAcousticModel";
	var respuesta= getFormModelCreation(response)
	var divShowData = document.getElementById('resultados');
	    divShowData.innerHTML = "<div><center> <b>Crear Modelo<b></center><br><br></div>"+respuesta;
}



function executeModelCreation()
{
	var modelName = document.querySelector('input[name="nombreModelo"]').value;
	var modelDesc = document.querySelector('input[name="descripcionModelo"]').value;
	if(modelName=="")
	{
		alert('rellene el campo de modelId');
		return;
	}
	var form_data = new FormData();                  
    form_data.append('name', modelName);
	form_data.append('description', modelDesc);
	var response =  "/addAcousticModel";
	crearModeloPersonalizado(form_data,response);
	clearAllModels();
}


async function entrenarModeloAcustico()
{
	var divShowData = document.getElementById('resultados');
	var modelosAcusticos = await obtenerModelos("/listAcousticModels");	
	var modelosLenguaje = await obtenerModelos("/listLanguageModels");
	modelosLenguaje= ["No language model", ...modelosLenguaje];
	
	var comboAcustico = "<center>"+crearCombo(modelosAcusticos)+"</center>";
	var comboLenguaje = "<center>"+crearCombo(modelosLenguaje)+"</center>";
	comboAcustico = comboAcustico.replace("class='inputText'", "class='inputText' id='comboAcoustic'");
	comboLenguaje = comboLenguaje.replace("class='inputText'", "class='inputText' id='comboLenguaje'");
	
	var urlEjecucion="/trainAcousticModel";
    var boton = "<div><center><button class='submitForm' onclick='makeAcousticModelTrain(\""+urlEjecucion+"\")'>Entrenar modelo acustico</button></center></div> ";

    divShowData.innerHTML = "<div><center> <b>Entrenar modelo acustico<b></center><br><br></div>"+comboAcustico+"<br>"+comboLenguaje+"<br>"+boton+"<br><br>";

}

	