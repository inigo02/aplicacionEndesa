
async function verModelosAcusticos (){   
	document.getElementById('resultados').innerHTML="";
	var jsonRespuesta = await obtenerInfoModelos("/listAcousticModels");
	var urlDeleteModel="/deleteAcousticModel";
	var funcionDelete="deleteModel";
	tableFromJson(jsonRespuesta,urlDeleteModel,funcionDelete);
	}
	
	
function createLanguageModel()
{
	var respuesta= getFormModel()
	var divShowData = document.getElementById('resultados');
	    divShowData.innerHTML = "<div><center> <b>Crear Modelo<b></center><br><br></div>"+respuesta;
}

function getFormModel()
{
	var resultado="<div id='wordEntry'>"
				+ "		<div id='inputFormRow'>"
				+ "			<div>"
				+ "				<p>Introduce nombre del modelo:<p>"
				+ "				<input type='text' name='nombreModelo' class='inputText' placeholder='Name of the word' autocomplete='off' required>"
				+ "			</div>"
				+ "			<div>"
				+ "				<p>Introduce descripcion del modelo:<p>"
				+ "				<input type='text' name='descripcionModelo' class='inputText' placeholder='Descripcion del modelo' autocomplete='off' required>"
				+ "			</div>"
			+ "			<div>"
				+ "		<button class='submitForm' onclick='executeModelCreation()'> Crear Modelo</button> "
				+ "		</div>"
				+ "	</div>"
				+ "</div>		";
	return resultado.trim();
}


function executeModelCreation()
{
	var modelName = document.querySelector('input[name="nombreModelo"]').value;
	var modelDesc = document.querySelector('input[name="descripcionModelo"]').value;
	if(modelName=="")
	{
		alert('rellene el campo de modelId');
		return;
	}
	var form_data = new FormData();                  
    form_data.append('name', modelName);
	form_data.append('description', modelDesc);
	var response =  "/addAcousticModel";
	crearModeloPersonalizado(form_data,response);
	clearAllModels();
}

	