
async function addCorpus()
{
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listAcousticModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
    var f= await getFileChooser("/addAudios");
    divShowData.innerHTML = "<div><center> <b>Subir ficheros al modelo de lenguaje<b></center><br><br></div>"+combo+"<br><br>"+f+"<br><br>";
}

async function listAudios()
{
	var divShowData = document.getElementById('resultados');
	var modelos = await obtenerModelos("/listAcousticModels");
	var combo = "<center>"+crearCombo(modelos)+"</center>";
	var obtenerList="/listAudios";
	var deleteWord="/deleteAudio";
    var boton = "<div><center><button class='submitForm' onclick='obtenerInfoResurces(\""+obtenerList+"\",\""+deleteWord+"\")'>Obtener lista de audios</button></center></div> ";
    divShowData.innerHTML = "<div><center> <b>Obtener audios que contiene el modelo Acústico seleccionado<b></center><br><br></div>"+combo+"<br>"+boton+"<br>";
}

