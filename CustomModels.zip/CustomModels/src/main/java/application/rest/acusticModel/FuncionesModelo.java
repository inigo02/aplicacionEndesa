package application.rest.acusticModel;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.AcousticModel;
import com.ibm.watson.speech_to_text.v1.model.AcousticModels;
import com.ibm.watson.speech_to_text.v1.model.CreateAcousticModelOptions;
import com.ibm.watson.speech_to_text.v1.model.DeleteAcousticModelOptions;
import com.ibm.watson.speech_to_text.v1.model.ListAcousticModelsOptions;

public class FuncionesModelo {
	SpeechToText speechToText;

	public FuncionesModelo(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}
	
	public String listarModelosAcusticos()
	{
		ListAcousticModelsOptions listAcousticModelsOptions =
				  new ListAcousticModelsOptions.Builder()
				    .language("es-ES")
				    .build();
		AcousticModels acousticModels = speechToText.listAcousticModels(listAcousticModelsOptions)
										.execute().getResult();
		return acousticModels.getCustomizations().toString();
	}
	
	public String crearModeloAcustico(String name, String description)
	{
    	CreateAcousticModelOptions createAcousticModelOptions =
    	  new CreateAcousticModelOptions.Builder()
    	    .name(name)
    	    .baseModelName("es-ES_NarrowbandModel")
    	    .description(description)
    	    .build();
    	AcousticModel acousticModel = speechToText.createAcousticModel(createAcousticModelOptions).execute().getResult();
    	return acousticModel.getCustomizationId();
	}
	
	public void deleteAcousticModel(String customizationId)
	{
		DeleteAcousticModelOptions deleteAcousticModelOptions =
				  new DeleteAcousticModelOptions.Builder()
				    .customizationId(customizationId)
				    .build();
		speechToText.deleteAcousticModel(deleteAcousticModelOptions).execute();
	}
}
