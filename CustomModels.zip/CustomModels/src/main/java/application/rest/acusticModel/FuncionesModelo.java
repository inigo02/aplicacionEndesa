package application.rest.acusticModel;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.AcousticModel;
import com.ibm.watson.speech_to_text.v1.model.AcousticModels;
import com.ibm.watson.speech_to_text.v1.model.CreateAcousticModelOptions;
import com.ibm.watson.speech_to_text.v1.model.DeleteAcousticModelOptions;
import com.ibm.watson.speech_to_text.v1.model.ListAcousticModelsOptions;
import com.ibm.watson.speech_to_text.v1.model.TrainAcousticModelOptions;

public class FuncionesModelo {
	SpeechToText speechToText;

	public FuncionesModelo(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}
	
	public String listarModelosAcusticos()
	{
		ListAcousticModelsOptions listAcousticModelsOptions =
				  new ListAcousticModelsOptions.Builder()
				    .language("es-ES")
				    .build();
		AcousticModels acousticModels = speechToText.listAcousticModels(listAcousticModelsOptions)
										.execute().getResult();
		return acousticModels.getCustomizations().toString();
	}
	
	public String crearModeloAcustico(String name, String description, String baseModel)
	{
		try {
    	CreateAcousticModelOptions createAcousticModelOptions =
    	  new CreateAcousticModelOptions.Builder()
    	    .name(name)
    	    .baseModelName(baseModel)
    	    .description(description)
    	    .build();
    	AcousticModel acousticModel = speechToText.createAcousticModel(createAcousticModelOptions).execute().getResult();
    	return acousticModel.getCustomizationId();
		}
		catch (Exception e) {
			return e.getMessage();
		}
    
	}
	
	public void deleteAcousticModel(String customizationId)
	{
		DeleteAcousticModelOptions deleteAcousticModelOptions =
				  new DeleteAcousticModelOptions.Builder()
				    .customizationId(customizationId)
				    .build();
		speechToText.deleteAcousticModel(deleteAcousticModelOptions).execute();
	}
	
	public String entrenarModelo( String customizationId,String languageCustomizationId)
	{
		String respuesta = "";
		try {
			TrainAcousticModelOptions trainAcousticModelOptions =
					  new TrainAcousticModelOptions.Builder()
					    .customizationId(customizationId)
					    .customLanguageModelId(languageCustomizationId)
					    .build();
	
			speechToText.trainAcousticModel(trainAcousticModelOptions).execute();
			respuesta="Se ha empezado a entrenar el modelo acustico";
		}catch(Exception e)
		{
			respuesta=e.getMessage();
		}
		return respuesta;
	}
}
