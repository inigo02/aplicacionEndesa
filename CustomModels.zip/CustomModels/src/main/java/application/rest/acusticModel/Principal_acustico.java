package application.rest.acusticModel;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.speech_to_text.v1.SpeechToText;

@Controller
public class Principal_acustico {
	String api_key_stt= "8uEzw_abjE73cc8IphYwDV6rXaHPHDZZqKv9jM1ZqX6u";
	String url_stt= "https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/39be799b-08e9-43f3-9269-71a23bc7cbf1"; 
	static SpeechToText speechToText;
	FuncionesModelo fModelo;
	FuncionesAudio fAudio;
	
	@RequestMapping(value = "/listAcousticModels" , method = RequestMethod.POST)
	@ResponseBody
	 public String getModelList()  
	{	
		iniciarServicios();	
		String resultado = fModelo.listarModelosAcusticos();
	    return resultado;			
	}
	
	@RequestMapping(value = "/addAcousticModel")
	@ResponseBody
	 public String addAcousticModel(@RequestParam("name") String name, @RequestParam("description") String description, @RequestParam("baseModel") String baseModel) 
	{		
		iniciarServicios();	
		String resultado = fModelo.crearModeloAcustico(name, description,baseModel);
		return "Id del modelo de lenguaje creado: "+resultado;	
	}
	
	@RequestMapping(value = "/addAudios")
	@ResponseBody
	 public String addAudios(@RequestParam("archivo_audio") MultipartFile multipart[],@RequestParam("modelID") String customizationId) 
	{		
		String resultado =fAudio.addAudioToAcousticModel(multipart, customizationId);
		return resultado;	
	}
	
	@RequestMapping(value = "/listAudios")
	@ResponseBody
	 public String listAudios(@RequestParam("modelID") String customizationId) 
	{		
		String resultado =fAudio.listarAudioResources(customizationId);
		return resultado;	
	}
		
	private void iniciarServicios() 
	{
		if(speechToText==null)
		{
			IamAuthenticator authenticator = new IamAuthenticator(api_key_stt);
	    	speechToText = new SpeechToText(authenticator);
	    	speechToText.setServiceUrl(url_stt);
			application.rest.languageModel.Principal_lenguaje.setSpeechToText(speechToText);
		}
		if(fModelo==null)
		{
			fModelo=new FuncionesModelo(speechToText);
			fAudio=new FuncionesAudio(speechToText);
		}
	}

	@RequestMapping(value = "/deleteAudio")
	@ResponseBody
	 public String deleteAudio(@RequestParam("modelID") String customizationId, @RequestParam("nombreElemento") String audioName) 
	{		
		System.out.println("deleting corpus "+audioName);
		fAudio.deleteAudio(customizationId, audioName);
		return audioName+" eliminado.";	
	}
	
	@RequestMapping(value = "/deleteAcousticModel")
	@ResponseBody
	 public String deleteAcousticModel(@RequestParam("modelID") String modelID) 
	{		
		System.out.println("deleting acoustic model "+modelID);
		fModelo.deleteAcousticModel(modelID);
		return modelID+" eliminado.";	
	}

	public static void setSpeechToText(SpeechToText speechToText) {
		Principal_acustico.speechToText = speechToText;
	}
	 
	@RequestMapping(value = "/trainAcousticModel")
	@ResponseBody
	 public String trainAcousticModel(@RequestParam("acousticModelID") String acousticModelID, @RequestParam("languageModelID") String languageModelID) 
	{		
		System.out.println("training acoustic model "+acousticModelID+". with language model"+languageModelID);
		languageModelID = languageModelID == "No language model"?null:languageModelID;
		String res = fModelo.entrenarModelo(acousticModelID, languageModelID);
		return "res";	
	
	}
}
