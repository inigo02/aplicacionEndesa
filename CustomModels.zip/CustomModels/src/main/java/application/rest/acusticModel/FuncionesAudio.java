package application.rest.acusticModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.stream.LongStream;

import org.springframework.web.multipart.MultipartFile;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.AddAudioOptions;
import com.ibm.watson.speech_to_text.v1.model.AudioResources;
import com.ibm.watson.speech_to_text.v1.model.DeleteAudioOptions;
import com.ibm.watson.speech_to_text.v1.model.ListAudioOptions;

public class FuncionesAudio {
	SpeechToText speechToText;
	
	public FuncionesAudio(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}
	
	public void añadirAudio(String customizationId,File file, String name, String type)
	{
		try {
			  AddAudioOptions addAudioOptions = new AddAudioOptions.Builder()
			    .customizationId(customizationId)
			    .contentType("audio/"+type)
			    .audioResource(file)
			    .audioName(name)
			    .build();

			  speechToText.addAudio(addAudioOptions).execute();
			  // Poll for audio status.
			} catch (FileNotFoundException e) {
			  e.printStackTrace();
			}
	}
	
	public String addAudioToAcousticModel(MultipartFile[] multipart, String customizationId)
	{
		String resultado;
		MultipartFile file = multipart[0];
		String filename=getFile(file);			
		File fileCreated= new File(filename);
		resultado=fileCreated.getName();
		String extension =  getFileExtension(filename);
		añadirAudio(customizationId, fileCreated, resultado, extension);
		return resultado;
		
	}
	
	private String getFile( MultipartFile file)
	{
		String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		String archivo_a_transcribir = null;
	    String uploadPath = "src/main/resources/public/archivosSubidos/";
		File uploadDir = new File(uploadPath);
		
		if (!uploadDir.exists()) {
			uploadDir.mkdir();
		}
		
		if (file.isEmpty()) {
			System.out.println(timeStamp + " Error: Archivo vacío");
		}
		try {
			String fileName = file.getOriginalFilename();
			System.out.println("fileName: " +fileName);
			InputStream is = file.getInputStream();
			archivo_a_transcribir = uploadPath + fileName;
			Files.copy(is, Paths.get(archivo_a_transcribir),
					StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			System.out.println(timeStamp + " Error: No ha sido posible copiar el archivo -> " + file.getName());
		}
        return archivo_a_transcribir;
	}
	
	public String getFileExtension( String fileName ) 
	{
	    int i = fileName.lastIndexOf('.');
	    if (i > 0) {
	        return fileName.substring(i+1);
	    } else 
	        return null;
	}
	
	public String listarAudioResources(String customizationId)
	{
		ListAudioOptions listAudioOptions = new ListAudioOptions.Builder()
				  .customizationId(customizationId)
				  .build();

		AudioResources audioResources =
		  speechToText.listAudio(listAudioOptions).execute().getResult();
				
		return audioResources.getAudio().toString();
	}
	
	public void deleteAudio(String customizationId,String audioName)
	{
		/*
		 * Removing an audio resource does not affect the custom model until you train the model on its updated data 
		 */
		DeleteAudioOptions deleteAudioOptions = new DeleteAudioOptions.Builder()
		  .customizationId(customizationId)
		  .audioName(audioName)
		  .build();
		speechToText.deleteAudio(deleteAudioOptions).execute();
	}

}
