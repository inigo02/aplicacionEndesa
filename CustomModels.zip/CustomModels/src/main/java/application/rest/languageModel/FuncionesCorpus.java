package application.rest.languageModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.AddCorpusOptions;
import com.ibm.watson.speech_to_text.v1.model.AddWordOptions;
import com.ibm.watson.speech_to_text.v1.model.Corpora;
import com.ibm.watson.speech_to_text.v1.model.Corpus;
import com.ibm.watson.speech_to_text.v1.model.DeleteCorpusOptions;
import com.ibm.watson.speech_to_text.v1.model.DeleteWordOptions;
import com.ibm.watson.speech_to_text.v1.model.ListCorporaOptions;
import com.ibm.watson.speech_to_text.v1.model.ListWordsOptions;
import com.ibm.watson.speech_to_text.v1.model.Words;

public class FuncionesCorpus {
	SpeechToText speechToText;
	
	public FuncionesCorpus(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}

	/*
	 * ADD CUSTOM WORD
	 */
	private void addWord(String[] opciones) {
		String customizationId = opciones[1];
		String wordname = opciones[2];
		String displayAs = opciones[3];
		List <String>soundslike=new ArrayList<>();
		for(int i=4;i<opciones.length;i++)
			soundslike.add(opciones[i]);
		addWordToModel(customizationId, wordname, displayAs, soundslike);
	}

	public void addWordToModel(String customizationId, String wordname, String displayAsString, List<String> soundsLike)
	{
		AddWordOptions addWordOptions = new AddWordOptions.Builder()
				  .customizationId(customizationId)
				  .wordName(wordname)
				  .soundsLike(soundsLike)
				  .displayAs(displayAsString)
				  .build();
		speechToText.addWord(addWordOptions).execute();
	}

		
	
	/*
	 * ADD CORPORA
	 */
	
	public String addCorpusToLanguageModel(MultipartFile[] multipart, String customizationId)
	{
		String resultado;
		MultipartFile file = multipart[0];
		String filename=getFile(file);			
		File fileCreated= new File(filename);
		resultado=fileCreated.getName();
		addCorpus( customizationId, fileCreated, resultado);
        boolean analizado=false;
        while(!analizado)
         {
        	 try {
        		  Thread.sleep(4000);
        	  }catch (InterruptedException e) {
        		  System.out.println(e.toString());
        		  continue;
        	  }
        	  analizado = isCorpusReady(customizationId, resultado);
          } 
		resultado+=" añadido correctamente.";
		return resultado;	
	}
	
	private String getFile( MultipartFile file)
	{
		String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		String archivo_a_transcribir = null;
	    String uploadPath = "src/main/resources/public/archivosSubidos/";
		File uploadDir = new File(uploadPath);
		
		if (!uploadDir.exists()) {
			uploadDir.mkdir();
		}
		
		if (file.isEmpty()) {
			System.out.println(timeStamp + " Error: Archivo vacío");
		}
		try {
			String fileName = file.getOriginalFilename();
			System.out.println("fileName: " +fileName);
			InputStream is = file.getInputStream();
			archivo_a_transcribir = uploadPath + fileName;
			Files.copy(is, Paths.get(archivo_a_transcribir),
					StandardCopyOption.REPLACE_EXISTING);
			
		} catch (IOException e) {
			System.out.println(timeStamp + " Error: No ha sido posible copiar el archivo -> " + file.getName());
		}
		
        return archivo_a_transcribir;
	}
	
	private void addCorpus(String customizationId, File file, String name)
	{
		try {
			  AddCorpusOptions addCorpusOptions = new AddCorpusOptions.Builder()
			    .customizationId(customizationId)
			    .corpusFile(file)
			    .corpusName(name)
			    .allowOverwrite(true)
			    .build();

			  speechToText.addCorpus(addCorpusOptions).execute();
			  // Poll for corpus status.
			} catch (FileNotFoundException e) {
			  e.printStackTrace();
			}
	}
	
	public boolean isCorpusReady(String customizationId,String corpusName)
	{
		Corpora c = listCorpora(customizationId);
		Optional<Corpus> matchingObject = c.getCorpora().stream().filter(corpus->corpus.getName().equals(corpusName)).findFirst();
		Corpus corpus = matchingObject.get();
		
		String analizado = corpus.getStatus();
		System.out.print(corpus.getStatus()+"   ");
		switch(analizado) {
			case "analyzed":
				return true;
		case "being_processed":
				return false;
		case "undetermined":
				System.out.println("The service encountered an error while processing the corpus. "+analizado);
				return true;		
		}		
		return false;
	}

	private Corpora listCorpora(String customizationId)
	{
		ListCorporaOptions listCorporaOptions = new ListCorporaOptions.Builder()
				  .customizationId(customizationId)
				  .build();
		Corpora corpora = speechToText.listCorpora(listCorporaOptions).execute().getResult();				
		
		return corpora;
				
	}


	public String listarficherosModelo(String customizationId) {
		ListCorporaOptions listCorporaOptions = new ListCorporaOptions.Builder()
				  .customizationId(customizationId)
				  .build();
		Corpora corpora = speechToText.listCorpora(listCorporaOptions).execute().getResult();
		return corpora.getCorpora().toString();
	}
	
	public String listPalabras(String customizationId)
	{
		ListWordsOptions listWordsOptions = new ListWordsOptions.Builder()
				  .customizationId(customizationId)
				  .sort("+alphabetical")
				  .build();
		Words words = speechToText.listWords(listWordsOptions).execute().getResult();
		
		return words.getWords().toString();
	}
	
	public void deleteWord(String customizationId, String wordname)
	{
		DeleteWordOptions deleteWordOptions = new DeleteWordOptions.Builder()
				  .customizationId(customizationId)
				  .wordName(wordname)
				  .build();

		speechToText.deleteWord(deleteWordOptions).execute();
	}
	
	public void deleteCorpus(String customizationId, String name) 
	{
		DeleteCorpusOptions deleteCorpusOptions = new DeleteCorpusOptions.Builder()
				  .customizationId(customizationId)
				  .corpusName(name)
				  .build();
		speechToText.deleteCorpus(deleteCorpusOptions).execute();
	}
	
	
}
