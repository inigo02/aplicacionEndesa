package application.rest.languageModel;




import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.AddCorpusOptions;
import com.ibm.watson.speech_to_text.v1.model.AddWordOptions;
import com.ibm.watson.speech_to_text.v1.model.Corpora;
import com.ibm.watson.speech_to_text.v1.model.Corpus;
import com.ibm.watson.speech_to_text.v1.model.CreateLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.LanguageModel;
import com.ibm.watson.speech_to_text.v1.model.LanguageModels;
import com.ibm.watson.speech_to_text.v1.model.ListCorporaOptions;

@Controller
public class Principal_lenguaje {
	String api_key_stt= "8uEzw_abjE73cc8IphYwDV6rXaHPHDZZqKv9jM1ZqX6u";
	String url_stt= "https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/39be799b-08e9-43f3-9269-71a23bc7cbf1"; 
	static SpeechToText speechToText;
	FuncionesCorpus fCorpus;
	FuncionesModelo fModelo;
	
	@RequestMapping(value = "/listLanguageModels" , method = RequestMethod.POST)
	@ResponseBody
	 public String getModelList()  
	{	
		iniciarServicios();
		String resultado = fModelo.listModels();
	    return resultado;			
	}
	
	@RequestMapping(value = "/addLanguageModel")
	@ResponseBody
	 public String addModel(@RequestParam("name") String name, @RequestParam("description") String description,  @RequestParam("baseModel") String baseModel) 
	{		
		iniciarServicios();
		String resultado = fModelo.createModel(name, description, baseModel);
		return "Id del modelo de lenguaje creado: "+resultado;	
	}
	
	
	@RequestMapping(value = "/addWord")
	@ResponseBody
	 public String addWord(@RequestParam("modelID") String customizationId, @RequestParam("wordName") String wordName, @RequestParam("displayAs") String displayAs, @RequestParam("soundsAs") String soundsAs) 
	{		
		List<String>lSoundsAs=Arrays.asList(soundsAs.split("--#--"));
		String resultado="Palabras creadas correctamente.";
		fCorpus.addWordToModel(customizationId, wordName, displayAs, lSoundsAs);
		return resultado;	
	}
	
	@RequestMapping(value = "/addCorpus")
	@ResponseBody
	 public String addCorpus(@RequestParam("archivo_audio") MultipartFile multipart[],@RequestParam("modelID") String customizationId) 
	{		
		
		String resultado =fCorpus.addCorpusToLanguageModel(multipart, customizationId);
		return resultado;	
	}
	
	@RequestMapping(value = "/listCorpus")
	@ResponseBody
	 public String listCorpus(@RequestParam("modelID") String customizationId) 
	{		
		String resultado =fCorpus.listarficherosModelo(customizationId);
		return resultado;	
	}
	
	@RequestMapping(value = "/listWords")
	@ResponseBody
	 public String listPalabras(@RequestParam("modelID") String customizationId) 
	{		
		String resultado =fCorpus.listPalabras(customizationId);
		return resultado;	
	}
	
	@RequestMapping(value = "/deleteWord")
	@ResponseBody
	 public String deleteWord(@RequestParam("modelID") String customizationId, @RequestParam("nombreElemento") String wordName) 
	{		
		System.out.println("deleting word "+wordName);
		fCorpus.deleteWord(customizationId, wordName);
		return wordName+" eliminado.";	
	}
	
	
	@RequestMapping(value = "/deleteCorpus")
	@ResponseBody
	 public String deleteCorpus(@RequestParam("modelID") String customizationId, @RequestParam("nombreElemento") String corpusName) 
	{		
		System.out.println("deleting corpus "+corpusName);
		fCorpus.deleteCorpus(customizationId, corpusName);
		return corpusName+" eliminado.";	
	}
		
	@RequestMapping(value = "/deleteLanguageModel")
	@ResponseBody
	 public String deleteLanguageModel(@RequestParam("modelID") String modelID) 
	{		
		System.out.println("deleting language model "+modelID);
		fModelo.deleteModel(modelID);
		return modelID+" eliminado.";	
	}
	
	
	@RequestMapping(value = "/trainLanguageModel")
	@ResponseBody
	 public String trainLanguageModel(@RequestParam("modelID") String modelID) 
	{		
		System.out.println("training language model "+modelID);
		String res = fModelo.train_model(modelID);
		return res;	
	}
	
	
	private void iniciarServicios() 
	{
		if(speechToText==null)
		{
			IamAuthenticator authenticator = new IamAuthenticator(api_key_stt);
	    	speechToText = new SpeechToText(authenticator);
	    	speechToText.setServiceUrl(url_stt);
			application.rest.acusticModel.Principal_acustico.setSpeechToText(speechToText);				
		}
		if(fModelo==null)
		{
			fCorpus = new FuncionesCorpus(speechToText);
			fModelo = new FuncionesModelo(speechToText);
		}
		
	}

	public static void setSpeechToText(SpeechToText speechToText) {
		Principal_lenguaje.speechToText = speechToText;
	}
	
	
	
}
