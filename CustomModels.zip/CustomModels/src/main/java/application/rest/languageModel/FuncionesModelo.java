package application.rest.languageModel;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.CreateLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.DeleteLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.LanguageModel;
import com.ibm.watson.speech_to_text.v1.model.LanguageModels;

public class FuncionesModelo {
	SpeechToText speechToText;

	public FuncionesModelo(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}
	
	public String listModels()
	{
		LanguageModels languageModels =
				  speechToText.listLanguageModels().execute().getResult();
		return languageModels.getCustomizations().toString();	
	}
	
	public String createModel(String name, String description, String baseModel )
	{
		CreateLanguageModelOptions createLanguageModelOptions =
				  new CreateLanguageModelOptions.Builder()
				    .name(name)
				    .baseModelName(baseModel)
				    .description(description)
				    .build();
		LanguageModel languageModel = speechToText.createLanguageModel(createLanguageModelOptions).execute().getResult();
		return languageModel.getCustomizationId();
	}
	
	public void deleteModel(String customizationId)
	{
		DeleteLanguageModelOptions deleteLanguageModelOptions =
				  new DeleteLanguageModelOptions.Builder()
				    .customizationId(customizationId)
				    .build();
		speechToText.deleteLanguageModel(deleteLanguageModelOptions).execute();
	}	
}
