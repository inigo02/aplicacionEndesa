package application.rest.languageModel;

import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.CreateLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.DeleteLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.LanguageModel;
import com.ibm.watson.speech_to_text.v1.model.LanguageModels;
import com.ibm.watson.speech_to_text.v1.model.TrainLanguageModelOptions;
import com.ibm.watson.speech_to_text.v1.model.TrainingResponse;
import com.ibm.watson.visual_recognition.v4.model.TrainingDataObject;

public class FuncionesModelo {
	SpeechToText speechToText;

	public FuncionesModelo(SpeechToText speechToText)
	{
		this.speechToText=speechToText;
	}
	
	public String listModels()
	{
		LanguageModels languageModels =
				  speechToText.listLanguageModels().execute().getResult();
		return languageModels.getCustomizations().toString();	
	}
	
	public String createModel(String name, String description, String baseModel )
	{
		CreateLanguageModelOptions createLanguageModelOptions =
				  new CreateLanguageModelOptions.Builder()
				    .name(name)
				    .baseModelName(baseModel)
				    .description(description)
				    .build();
		LanguageModel languageModel = speechToText.createLanguageModel(createLanguageModelOptions).execute().getResult();
		return languageModel.getCustomizationId();
	}
	
	public void deleteModel(String customizationId)
	{
		DeleteLanguageModelOptions deleteLanguageModelOptions =
				  new DeleteLanguageModelOptions.Builder()
				    .customizationId(customizationId)
				    .build();
		speechToText.deleteLanguageModel(deleteLanguageModelOptions).execute();
	}	
	
	public String train_model(String customizationId)
	{
		String respuesta = "";
		try {
		TrainLanguageModelOptions trainLanguageModelOptions =
				  new TrainLanguageModelOptions.Builder()
				    .customizationId(customizationId)
				    .build();

		TrainingResponse res= speechToText.trainLanguageModel(trainLanguageModelOptions).execute().getResult();
		respuesta="Se ha empezado a entrenar el modelo";
		}catch(Exception e)
		{
			respuesta=e.getMessage();
		}
		
		
		return respuesta;
	}
}
