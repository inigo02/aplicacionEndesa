package application.rest.conversationFie;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;

import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.RecognizeOptions;
import com.ibm.watson.speech_to_text.v1.model.SpeakerLabelsResult;
import com.ibm.watson.speech_to_text.v1.model.SpeechRecognitionAlternative;
import com.ibm.watson.speech_to_text.v1.model.SpeechRecognitionResults;
import com.ibm.watson.speech_to_text.v1.model.SpeechTimestamp;

import application.rest.conversacion.Speech;

public class PrincipalWrite {

	SpeechToText speechToText;
	List<List<TimeStampWord>> timeWords;
	List<String> transcriptionWords;
	List<Transcripcion> transcripciones;
	List<Speech> lSpeech;
	String saveName="C:\\Users\\blatx\\Documents\\Iñigo\\Nubeum\\Comparacion\\";
	String fileIzena = "EMMNZ082_PBC0171EM_0031406035413001WY04122020678686177N10";
	TranscripcionSer transcriptSer;
	//String tipoModelo="_tlf";
	//String tipoModelo="_tlf_language";
	String tipoModelo="_narrow";
	public PrincipalWrite()
	{
		transcripciones=new ArrayList<>();	
	}

	public void ejecutar()
	{
		String fileName="C:\\nubeum\\audios\\nuevos audios\\EMERGIA MANIZALES\\VENTAS\\"+fileIzena+".wav";
		//		      OutputStream file = new FileOutputStream("C:\\Users\\blatx\\Documents\\Iñigo\\Nubeum\\DIMNZ517_COE0437DI_0031300025018008EC01122020651959415N10.ser");
		initSpeechToTextService();
		SpeechRecognitionResults transcript=transcribeFile(fileName);
		crearTodo(transcript);
		imprimir();
		
		lSpeech = getSpeakersSpechtime(transcript);
		transcriptSer = new TranscripcionSer(transcripciones, lSpeech);
		writeTranscription();
	}
	
	private void imprimir() {
		for(Transcripcion t : transcripciones)
		{
			String timeStamp = t.getTimeWords().stream().map(TimeStampWord::getWord).collect(Collectors.joining(" "));
			String transcri = t.getTranscriptionWords();
		}	
	}
	
	public SpeechRecognitionResults transcribeFile(String archivo_a_transcribir)
	{
    	
	    File audio = new File(archivo_a_transcribir);
	    SpeechRecognitionResults transcript = null;
	    String languageCustomizationId="11b90cdf-ab20-4ed3-a7ff-c54e43c23f49";
	    String customizationId="60535b3c-853d-4434-877e-b479a29e6cec";
	    
	   // String languageCustomizationId="369d8485-f1f6-4468-abff-dcef95bca3a5";
   	 	String extension = FilenameUtils.getExtension(archivo_a_transcribir);
   	 	//float sensitivity = 0.05f;
	    try {
			RecognizeOptions recognizeOptions  = new RecognizeOptions.Builder()
					.audio(audio)
					.contentType("audio/"+extension)
					.model("es-ES_NarrowbandModel")
					.acousticCustomizationId(customizationId)
					//.model("es-ES_Telephony")
					.languageCustomizationId(languageCustomizationId)
					
					.speechDetectorSensitivity(0.7f)
					.smartFormatting(true)
					.speakerLabels(true)
					.build();			
			transcript = speechToText.recognize(recognizeOptions).execute().getResult();
		} catch (Exception ex) {
			//watson_respuesta =watson_respuesta+ "Error Watson Speech-to-text "+ex.getMessage()+" <br> file: "+audio.getAbsolutePath();
			System.out.println(ex.toString());
		}
	    return transcript;
	}

	public List<TimeStampWord> getWordTimeStamp(SpeechRecognitionAlternative speechRecognitionAlternative)
	{
		List<TimeStampWord> res = speechRecognitionAlternative.getTimestamps().stream()
				.map( ts -> { 
					return crearTimeStampWord(ts);
				})
				.collect(Collectors.toList());
		return res;
	}

	public TimeStampWord crearTimeStampWord(SpeechTimestamp ts)
	{
		String text = ts.getWord();
		double start = ts.getStartTime();
		double end = ts.getEndTime();
		
		return new TimeStampWord(text, start, end);
	}
	
	public void crearTodo(SpeechRecognitionResults transcript)
	{
		transcriptionWords = transcript.getResults().stream().map(e-> e.getAlternatives().get(0).getTranscript()).collect(Collectors.toList());
		timeWords = transcript.getResults().stream()
				.map(e-> { 
					return getWordTimeStamp(e.getAlternatives().get(0));
					} )
				.collect(Collectors.toList());;
				
		for(int i=0; i<transcriptionWords.size(); i++)
		{
			String t = transcriptionWords.get(i);
			List<TimeStampWord> lts = timeWords.get(i);
			Transcripcion transcripcion = new Transcripcion(lts, t);
			transcripciones.add(transcripcion);
			
		}
		
	}
	
	public void initSpeechToTextService()
	{
		String api_key_stt= "8uEzw_abjE73cc8IphYwDV6rXaHPHDZZqKv9jM1ZqX6u";
		String url_stt= "https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/39be799b-08e9-43f3-9269-71a23bc7cbf1"; 
		IamAuthenticator authenticator = new IamAuthenticator(api_key_stt);
		speechToText = new SpeechToText(authenticator);
		speechToText.setServiceUrl(url_stt);
	}
	
	public static void main(String[] args) {
		PrincipalWrite app= new PrincipalWrite();
		app.ejecutar();
	}
	
	
	private List<Speech> getSpeakersSpechtime(SpeechRecognitionResults transcript)
	{		
	    List<Speech> speechList = new ArrayList<>();
		Float speechStartSecond = 0F,speechEndSecond=0F;
	    Long idAnterior=0L, idActual=0L;
	    
	    if(transcript.getSpeakerLabels()==null)	
	    	return speechList;
	    
	    for (SpeakerLabelsResult spk: transcript.getSpeakerLabels()) 
	    {
	    	idActual=spk.getSpeaker();
	        if (!isSameSpeaker(idAnterior, idActual))
	        {
	        	speechList.add(new Speech(speechStartSecond,speechEndSecond,idAnterior));	        	 
	        	speechStartSecond=spk.getFrom();
	        	idAnterior=idActual;
	        }
	        speechEndSecond=spk.getTo();
	    }
	    speechList.add(new Speech(speechStartSecond,speechEndSecond,idAnterior));
	    return speechList;
	}
	

	private boolean isSameSpeaker(Long idAnterior, Long idActual)
	{
		return idAnterior == idActual;
	}
	
	public void writeTranscription()
	{
	
		try{
		      //use buffering
		      OutputStream file = new FileOutputStream(saveName+fileIzena+tipoModelo+".ser");
		      OutputStream buffer = new BufferedOutputStream(file);
		      ObjectOutput output = new ObjectOutputStream(buffer);
		      try{
		        output.writeObject(transcriptSer);
		      }
		      finally{
		        output.close();
		      }
		    } catch(IOException ex){		    	
		    	System.out.println("Cannot perform output."+ ex);
		    }
	}
	
	private void writeTranscript(SpeechRecognitionResults transcript) {
		
		PrintWriter writer;
		try {
			writer = new PrintWriter("tlf"+saveName+"transcript_"+fileIzena+".txt", "UTF-8");
			writer.println(transcript);
			writer.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
}
