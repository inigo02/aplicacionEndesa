package textAnalysis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.natural_language_understanding.v1.model.DocumentSentimentResults;
import com.ibm.watson.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.natural_language_understanding.v1.model.EntitiesResult;
import com.ibm.watson.natural_language_understanding.v1.model.EntityMention;
import com.ibm.watson.natural_language_understanding.v1.model.Features;
import com.ibm.watson.natural_language_understanding.v1.model.SentimentOptions;

import application.rest.conversacion.Conversation;
import application.rest.conversacion.Lista_conversaciones;


public class KnowledgeStudio_ventas 
{
	NaturalLanguageUnderstanding naturalLanguageUnderstanding;
	String modelID;
	Map<String, DocumentSentimentResults>mapSentimientos;
	List<Conversation> lConversaciones;
	List<EntitiesResult> lEntities;
	
	public KnowledgeStudio_ventas(String NLU_apikey, String NLU_url_key, String modelID, Lista_conversaciones lista_conversaciones)
	{
		this.modelID=modelID;
		this.lConversaciones=lista_conversaciones.getConversation_list();		
		mapSentimientos=new HashMap<String, DocumentSentimentResults>();	
		IamAuthenticator authenticator = new IamAuthenticator(NLU_apikey);
		naturalLanguageUnderstanding = new NaturalLanguageUnderstanding("2020-08-01", authenticator);
		naturalLanguageUnderstanding.setServiceUrl(NLU_url_key);
	}
		
	public void findEntitiesInTranscription() 
	{
		List<String> lAllConversations=new ArrayList<>(Arrays.asList("Cliente","Agente"));
		String transcripcion=getStringTranscription(lAllConversations);
		lEntities=searchEntities(transcripcion);
		addEntitiesToEachConv();
		searchSentiments();	
	}
	
	private String getStringTranscription(List<String> lAllConversations) 
	{
		List <Conversation>convsFiltered = lConversaciones.stream().filter(c -> lAllConversations.contains(c.getNombre())).collect(Collectors.toList());
		String transcripcion = convsFiltered.stream().map(Conversation::getText).collect(Collectors.joining(" "));
		return transcripcion;
	}
	
	private List<EntitiesResult> searchEntities(String transcripcion) 
	{
		EntitiesOptions entities= new EntitiesOptions.Builder()
				.sentiment(true)
				.mentions(true)
				.model(modelID)
				.build();
		
		Features features = new Features.Builder()
				.entities(entities)
				.build();
		
		AnalyzeOptions parameters = new AnalyzeOptions.Builder()
				.text(transcripcion)
				.language("es")
				.features(features)
				.build();
		
		AnalysisResults response = naturalLanguageUnderstanding
		  .analyze(parameters)
		  .execute()
		  .getResult();
		
		return response.getEntities();
	}
	
	private void addEntitiesToEachConv() 
	{		
		for (EntitiesResult e:lEntities) {
	        for (EntityMention m:e.getMentions())
	        {
	        	int start_position=m.getLocation().get(0).intValue(), end_position=m.getLocation().get(1).intValue();
	        	int[] convData = findEntitycorrespondentConv(start_position, end_position,e);
	        	lConversaciones.get(convData[0]).add_entity(e, convData[1], convData[2]);
	        }
		}
	}

	private int[] findEntitycorrespondentConv( int start_position, int end_position, EntitiesResult e)
	{
		int[] conversationFinded = null;
		int viwedConvsSize=0;		
		for( int i=0; i<lConversaciones.size(); i++) 
		{
			Conversation c = lConversaciones.get(i);
			int actualConvSize=c.getText().length()+" ".length();
			if(isEntityInActualConv(viwedConvsSize,start_position,end_position,actualConvSize))
			{
				start_position=start_position-viwedConvsSize;
				end_position=end_position-viwedConvsSize;
				conversationFinded = new int[]{i, start_position, end_position};
				break;
			}
			viwedConvsSize+=actualConvSize;
		}
		return conversationFinded;
	}
	
	private boolean isEntityInActualConv(int viwedConvsSize, int start_position, int end_position, int actualConvSize){
		return viwedConvsSize<=start_position && end_position<viwedConvsSize+actualConvSize;
	}
	
	private void searchSentiments()
	{		
		searchSentimentsInText("agente", new String[]{"Agente"});
		searchSentimentsInText("titular", new String[]{"Cliente"});
		searchSentimentsInText("total", new String[]{"Cliente","Agente"});	
	}
		
	private void searchSentimentsInText( String speakerKey, String[] speaker)
	{
		List<String> lspeaker=new ArrayList<>(Arrays.asList(speaker));
		String filteredTranscription=getStringTranscription(lspeaker);
		DocumentSentimentResults sentiment=getConvSentiment(filteredTranscription);
		mapSentimientos.put(speakerKey, sentiment);
	}
	
	private DocumentSentimentResults getConvSentiment(String text) {
	
			SentimentOptions sentiment = new SentimentOptions.Builder()
			  .build();
	
			Features features = new Features.Builder()
			  .sentiment(sentiment)
			  .build();
	
			AnalyzeOptions parameters = new AnalyzeOptions.Builder()
			  .text(text)
			  .features(features)
			  .language("es")
			  .build();
	
			AnalysisResults response = naturalLanguageUnderstanding
			  .analyze(parameters)
			  .execute()
			  .getResult();
			
			DocumentSentimentResults sentimentVal= response.getSentiment().getDocument();
			return sentimentVal;
		}
	
	public List<EntitiesResult> getlEntities() {
		return lEntities;
	}
	
	public List<Conversation> getlConversaciones() {
		return lConversaciones;
	}

	public Map<String, DocumentSentimentResults> getMapSentimientos() {
		return mapSentimientos;
	}	
}
