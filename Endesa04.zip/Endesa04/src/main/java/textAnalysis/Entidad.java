package textAnalysis;

import com.ibm.watson.natural_language_understanding.v1.model.EntitiesResult;

public class Entidad implements Comparable<Object>{
	EntitiesResult entidad;
	int init,end;
	public Entidad(EntitiesResult entidad,int init,int end)
	{
		this.entidad=entidad;
		this.init=init;
		this.end=end;
	}
	public EntitiesResult getEntidad() {
		return entidad;
	}
	public int getInit() {
		return init;
	}
	public int getEnd() {
		return end;
	}
	@Override
	public int compareTo(Object o) {
		Entidad e=(Entidad) o;
		
		return e.getInit()-this.init;
	}
}
