package application.rest.conversacion;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.io.FilenameUtils;
import com.ibm.cloud.sdk.core.security.IamAuthenticator;
import com.ibm.watson.speech_to_text.v1.SpeechToText;
import com.ibm.watson.speech_to_text.v1.model.RecognizeOptions;
import com.ibm.watson.speech_to_text.v1.model.SpeakerLabelsResult;
import com.ibm.watson.speech_to_text.v1.model.SpeechRecognitionAlternative;
import com.ibm.watson.speech_to_text.v1.model.SpeechRecognitionResult;
import com.ibm.watson.speech_to_text.v1.model.SpeechRecognitionResults;
import com.ibm.watson.speech_to_text.v1.model.SpeechTimestamp;
import application.rest.conversationFie.FileConversation;

public class Lista_conversaciones {
	SpeechToText speechToText;
	List<Conversation> conversation_list;
	float tiempo_inicio=0;
	String customizationId,languageCustomizationId, api_key_stt, url_stt ;
	String file_name;
	
	public Lista_conversaciones(String api_key_stt, String url_stt, String customizationId, String languageCustomizationId)
	{
		this.api_key_stt=api_key_stt;
		this.url_stt=url_stt;
		this.customizationId=customizationId;
		this.languageCustomizationId=languageCustomizationId;
	   	conversation_list=new ArrayList<>(); 			
	}
	
	public void transcribir_audio(String filename) throws Exception
	{
		this.file_name=FilenameUtils.getName(filename);
		FileConversation fileConv;
		String extension=FilenameUtils.getExtension(filename);
		switch (extension) {
		case "txt":
			fileConv = new FileConversation();
			fileConv.obtenerConversacionTxt(filename, conversation_list);
			break;
		case "ser":
			fileConv = new FileConversation();
			fileConv.formatearInformacionSer(filename);
			List<Speech> lspeechTimes=fileConv.getSpeechList();
			List<Word> lSpokenWords=fileConv.getWord_listAll();
			createConversations(lspeechTimes,lSpokenWords);
			break;
		default:
			initSpeechToTextService();			
			SpeechRecognitionResults transcript=transcribeFile(filename);
			getAllConversations(transcript);
			break;
		}
		determinar_participantes();	
	}
	
	private void initSpeechToTextService() throws Exception
	{
		try {
			IamAuthenticator authenticator = new IamAuthenticator(api_key_stt);
			speechToText = new SpeechToText(authenticator);
			speechToText.setServiceUrl(url_stt);
		}
		catch (Exception e) {
			throw new Exception("error al iniciar el servicio de speech to text. "+e.getMessage());
		}
	}
	
	private void determinar_participantes()
	{
		Long agente=encontrarAgente();
		conversation_list.forEach(c-> c.setNombre(getSpeaker(c,agente)));
	}
	
	private String getSpeaker(Conversation c, Long agente) {
		return c.getSpeaker().equals(agente)? "Agente":"Cliente";
	}

	private Long encontrarAgente()
	{
		Conversation cAgente = conversation_list.stream()
				.filter( c-> c.getText().toLowerCase().contains("endesa") )
				.findFirst().orElse(null);
		Long agente=cAgente==null?1:cAgente.getSpeaker();
		return agente;
	}

	private SpeechRecognitionResults transcribeFile(String archivo_a_transcribir) throws Exception
	{
	    File audio = new File(archivo_a_transcribir);
	    SpeechRecognitionResults transcript = null;
   	 	String extension = FilenameUtils.getExtension(archivo_a_transcribir);
		try {
			RecognizeOptions recognizeOptions  = new RecognizeOptions.Builder()
						.audio(audio)
						.contentType("audio/"+extension)
						.model("es-ES_NarrowbandModel")
						.acousticCustomizationId(customizationId)
						.languageCustomizationId(languageCustomizationId)
						.smartFormatting(true)
						.speakerLabels(true)
						.build();			
				transcript = speechToText.recognize(recognizeOptions).execute().getResult();
		   }catch (Exception e) {
			   throw new Exception("Error al transcribir audio. "+e.getMessage());
		   }
	   return transcript;
	}
	
	private void getAllConversations(SpeechRecognitionResults transcript) throws Exception
	{
		List<Speech> lspeechTimes=getSpeakersSpechtime(transcript);
		List<Word> lSpokenWords=getSpokenWords(transcript);
		createConversations(lspeechTimes,lSpokenWords);
	}
	
	private List<Speech> getSpeakersSpechtime(SpeechRecognitionResults transcript)
	{	
		/*
		 * Se obtienen en que rango de tiempo habla cada una de las personas participantes en la conversacion.
		 * La clase Speech contiene, el id del hablante el segundo en el que empieza a hablar y el segundo que termina de hablar.
		 */
	    List<Speech> speechList = new ArrayList<>();
		Float speechStartSecond = 0F,speechEndSecond=0F;
	    Long idAnterior=0L, idActual=0L;
	    
	    if(transcript.getSpeakerLabels()==null)	
	    	return speechList;
	    
	    for (SpeakerLabelsResult spk: transcript.getSpeakerLabels()) 
	    {
	    	idActual=spk.getSpeaker();
	        if (!isSameSpeaker(idAnterior, idActual))
	        {
	        	speechList.add(new Speech(speechStartSecond,speechEndSecond,idAnterior));	        	 
	        	speechStartSecond=spk.getFrom();
	        	idAnterior=idActual;
	        }
	        speechEndSecond=spk.getTo();
	    }
	    speechList.add(new Speech(speechStartSecond,speechEndSecond,idAnterior));
	    return speechList;
	}
	
	private boolean isSameSpeaker(Long idAnterior, Long idActual)
	{
		return idAnterior == idActual;
	}
	
	private void createConversations(List<Speech> lspeechTimes, List<Word> lSpokenWords)
	{
		for( Speech sp: lspeechTimes) 
		{
			float speechEndSecond=sp.getEnd(), speechStartSecond = sp.getInit();	
			List<Word>addedWords = identifiedSpeechText(lSpokenWords, speechEndSecond);
			
			if(!addedWords.isEmpty())
			{
				Long speaker = sp.getSpeaker();
				String speechText = addedWords.stream().map(Word::getText).collect(Collectors.joining(" "));
				conversation_list.add(new Conversation(speaker, speechText, speechStartSecond, speechEndSecond));
				lSpokenWords.removeAll(addedWords);
			}
		}
	}
	
	private List<Word> identifiedSpeechText(List<Word> lSpokenWords,float speechEndSecond )
	{
		List<Word>addedWords=new ArrayList<>();
		for(Word word:lSpokenWords) 
		{
			if(isWordInSameConversation(word.getEnd(), speechEndSecond))
			{
				addedWords.add(word);
				continue;
			}
			break;
		}
		return addedWords;
	}
	
	private boolean isWordInSameConversation(float wordEndSecond, float speechEndSecond)
	{
		return wordEndSecond<=speechEndSecond;
	}
		
	private List<Word> getSpokenWords(SpeechRecognitionResults transcript) throws Exception
	{
		/*
		 * En esta funcion se obtienen todas las palabras que aparecen en el audio y en que segundo se dicen.
		 */
		List<Word>word_listAll=new ArrayList<>();
	    
		for(SpeechRecognitionResult result: transcript.getResults())
		{	
			SpeechRecognitionAlternative resultAlternative=result.getAlternatives().get(0);
			List<String> wordsTranscript = getTranscriptedWords(resultAlternative);
			List<SpeechTimestamp> timeStamps = resultAlternative.getTimestamps();
			
			List<Word> word_list=obtenerPalabras(timeStamps, wordsTranscript);
			word_listAll.addAll(word_list);
			
			
			imprimirIncorrectConvs(resultAlternative.getTranscript(), word_list, timeStamps.stream().map(e->e.getWord()).collect(Collectors.joining(" ")));
		}

		return word_listAll;
	}
	
	private void imprimirIncorrectConvs(String transcriptText, List<Word> word_list, String allTextTimeStamp ) {		
		String wordsCreated = word_list.stream().map(Word::getText).collect(Collectors.joining(" "));
		List<String> wordsTranscript = new ArrayList<>(Arrays.asList(transcriptText.split(" ")));
		String textTranscript = wordsTranscript.stream().collect(Collectors.joining(" "));
		if(!wordsCreated.equals(textTranscript))
		 {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("timeStamp :    "+allTextTimeStamp);
			System.out.println("transcript:    "+textTranscript);
			System.out.println("words created: "+wordsCreated);
			System.out.println("----------------------------------");
			System.out.println();
		 }
	}
	
	private List<String> getTranscriptedWords(SpeechRecognitionAlternative resultAlternative)
	{
		String transcriptText = resultAlternative.getTranscript().replace("  "," ");
		return new ArrayList<>(Arrays.asList(transcriptText.split(" ")));
	}
	
	private List<Word> obtenerPalabras(List<SpeechTimestamp> timeStamps, List<String> wordsTranscript) throws Exception
	{
		List<Word>word_list=new ArrayList<>();
		
		while(timeStamps.size()>0)
		{
			try {
				String text_timestamp = timeStamps.get(0).getWord(), text_transcript = wordsTranscript.get(0);
				int nTranscriptWordsToDelete=0, nTimestampWordsToDelete=0;
				if(!text_transcript.equals(text_timestamp))
				{
					/*
					 * Este caso puede ocurre cuando el resultado de timstamp no es el mismo que la de la transcripcion.
					 * Ejemplos
					 * TimeStamp: arroba gmail . com   || transcript: @gmail.com
					 * TimeStamp: cincuenta y dos   || transcript: 52
					 *  ....
					 *  En estos casos se encuentra la proxima palabra que coincide 
					 *  ejemplos:
					 *  timeStamp: 12 de marzo || transcript: doce de marzo || resultado, identifica que de es igual, coge el 12 y le da el tiempo de inicio y de final que tiene el timestamp del doce.
					 */
					
					 if(containsWord(text_timestamp, text_transcript))
						nTranscriptWordsToDelete = findNumerOfContainingWords(text_timestamp, wordsTranscript);
					 
					 else if(containsWord(text_transcript, text_timestamp ))
					 {
						 List<String>lWordsTimeStamps = getAllWordsTimeStamp(timeStamps);
						 nTimestampWordsToDelete = findNumerOfContainingWords(text_transcript, lWordsTimeStamps);
					 }
					 
					 else if(isLastTranscriptWord(wordsTranscript, nTranscriptWordsToDelete))
						 nTimestampWordsToDelete=timeStamps.size()-1;
					 
					 else { /* if textTranscript is or contains a number*/
						 nTranscriptWordsToDelete = getallNumbers(wordsTranscript);
						 nTimestampWordsToDelete = getnumOfTimeStampWordsToDeletedWhenNumeric(timeStamps, wordsTranscript, nTranscriptWordsToDelete);
					 }
				}
				Word word = createWord(timeStamps, nTimestampWordsToDelete, wordsTranscript,nTranscriptWordsToDelete);
				word_list.add(word);
				deleteWords(timeStamps, nTimestampWordsToDelete, wordsTranscript,nTranscriptWordsToDelete);
			}catch (Exception e) {
				throw new Exception("Problemas al obtener palabras del SpeechRecognitionResults. "+e.getMessage());
			}
		}
		
		return word_list;
	}

	private int getnumOfTimeStampWordsToDeletedWhenNumeric(List<SpeechTimestamp> timeStamps, List<String> wordsTranscript, int nTranscriptWordsToDelete )
	{
		List<String>lWordsTimeStamps = getAllWordsTimeStamp(timeStamps);
		int nTimestampWordsToDelete = isLastTranscriptWord(wordsTranscript,nTranscriptWordsToDelete)?
				 timeStamps.size()-1 : findNextNoNumericTimeStampWord(wordsTranscript, nTranscriptWordsToDelete+1, lWordsTimeStamps);
		return nTimestampWordsToDelete;
	}
	private Word createWord(List<SpeechTimestamp> timeStamps, int nTimestampWordsToDelete, List<String> wordsTranscript,
			int nTranscriptWordsToDelete) {
			
		String text_transcript = getTranscriptWord(wordsTranscript, nTranscriptWordsToDelete);
		double init= timeStamps.get(0).getStartTime();
		double end=timeStamps.get(nTimestampWordsToDelete).getEndTime();
		Word word = new Word(text_transcript, init, end);
		
		return word;
	}
	
	private boolean containsWord(String word1,String word2) {
		word1=formatWord(word1);
		word2=formatWord(word2);
		return word1.contains(word2);
	}
	
	private String formatWord(String word){
		return word.replace(",", "coma").replace(".", "punto");
	}
	
	private int findNumerOfContainingWords( String wordContainer, List<String> lContainedWords) {
		int numOfContainedWords;
		wordContainer=formatWord(wordContainer);
		for(numOfContainedWords=0; numOfContainedWords<lContainedWords.size();numOfContainedWords++)
		{
			String containedWord = lContainedWords.get(numOfContainedWords);
			String formattedContainedWord = formatWord(containedWord);
			if(!wordContainer.startsWith(formattedContainedWord))
				break;
			wordContainer=wordContainer.replace(formattedContainedWord, "");
		}	
		numOfContainedWords--;
		return numOfContainedWords;
	}
	
	private List<String> getAllWordsTimeStamp(List<SpeechTimestamp> timeStamps){
		return timeStamps.stream().map(SpeechTimestamp::getWord).collect(Collectors.toList());
	}

	private boolean isLastTranscriptWord(List<String> wordsTranscript, int actualIndex) {
		return wordsTranscript.size()==actualIndex+1;
	}
	
	private boolean isWordANumber(String strNum) {
	    try {
	    	strNum = strNum.replace(",", ".");
	    	strNum = strNum.replace("€", "");
	    	strNum = strNum.replace(":", "");
	    	strNum = strNum.replace("/", "");
	    	strNum = strNum.replace("%", "");
	    	strNum = strNum.replace("-", "");
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	private int getallNumbers(List<String> wordsTranscript) {
		int kont=1;
		for (int i=1; i<wordsTranscript.size();i++)
		{
			String word= wordsTranscript.get(i);
			if(!isWordANumber(word) && word.length()>2 )
			{
				if(word.contains(","))
				{
					kont++;
					continue;
				}
				break;
			}
			kont++;
		}
		if(kont+1<wordsTranscript.size())
			kont =  wordsTranscript.get(kont).equals("punto") && wordsTranscript.get(kont+1).equals("5")? kont+2 : kont;
		kont--;
		return kont;
	}
	
	private int findNextNoNumericTimeStampWord( List<String> wordsTranscript, int indexNextWordTranscript, List<String> lContainedWords) 
	{
		String nextWordTranscript = wordsTranscript.get(indexNextWordTranscript);
		int numOfContainedWords;
		for(numOfContainedWords=1; numOfContainedWords<lContainedWords.size();numOfContainedWords++)
		{
			String containedWord = lContainedWords.get(numOfContainedWords);
			String formattedContainedWord=containedWord;
			
			if((nextWordTranscript.startsWith(formattedContainedWord) || formattedContainedWord.startsWith(nextWordTranscript)) && formattedContainedWord.length()>2)
				break;
		}	
		numOfContainedWords--;
		return numOfContainedWords;
	}
	
	private String getTranscriptWord(List<String> wordsTranscript, int transcriptPassedWords) 
	{
		String text="";
		for(int i=0;i<=transcriptPassedWords;i++)
			text += wordsTranscript.get(i)+" ";
		text= text.substring(0, text.length() - 1);
		return text;
	}
	
	private void deleteWords(List<SpeechTimestamp> timeStamps, int nTimestampWordsToDelete, List<String> wordsTranscript, int nTranscriptWordsToDelete)
	{
		for(int i=0; i<=nTranscriptWordsToDelete; i++)
			 wordsTranscript.remove(0);
		for(int i=0; i<=nTimestampWordsToDelete; i++)
			timeStamps.remove(0);		
	}
	
	public List<Conversation> getConversation_list() {
		return new ArrayList<Conversation>(conversation_list);
	}
	
}
