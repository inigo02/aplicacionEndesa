package application.rest.conversacion;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.watson.natural_language_understanding.v1.model.EntitiesResult;

import textAnalysis.Entidad;

public class Conversation {

	String text, nombre,textoFormateado;
	List<Entidad> lista_entities;
	Long speaker;
	float init, end;
	
	public Conversation( Long speaker, String text, float init, float end)
	{
		this.text=text + ".";
		this.textoFormateado=text;
		this.speaker=speaker;
		this.end=end;
		this.init=init;
		lista_entities=new ArrayList<>();
		aplicarExpresionesRegulares();
	}
	
	public void add_entity(EntitiesResult e,int init, int end)
	{
		Entidad entidad=new Entidad(e, init, end);
		lista_entities.add(entidad);
	}
	
	private void aplicarExpresionesRegulares()
	{
		List<String>lRemoveCharacters = new ArrayList<>();
		//quitar espacios en el gmail y escribir @gmail.com....
		String regular_expresion="([A-Za-z]{3,25}+\\s(\\d+\\s)*)arroba+(\\s(yahoo|hotmail|gmail)\\.(com|es|net))";
		String remplazo="$1@$3";
		lRemoveCharacters.add(" ");
		text=applicar_regex(text,regular_expresion,remplazo,lRemoveCharacters);
		
		//reemplazar "por ciento", "porciento" o "por 100" por "%"
		regular_expresion="(\\d+\\s*) por(ciento| ciento| 100)";
		remplazo="$1%";
		lRemoveCharacters.clear();
		text=applicar_regex(text,regular_expresion,remplazo,lRemoveCharacters);
		
		//escribir bien las paginas web por ejemplo "triple doble uve doble punto endesa.com" convertir a "www.endesa.com"
		regular_expresion="(triple uve doble punto|www.|triple u punto| triple doble uve punto)((\\w*\\W*){0,6}).com";
		remplazo="www.$2.com";
		lRemoveCharacters.add(" ");
		text=applicar_regex(text,regular_expresion,remplazo,lRemoveCharacters);
		
		regular_expresion="(www.endesa.com o )www\\.((\\w*\\W*){0,1})(.com)";
		remplazo="www.endesa.com o www.endesastore.com";
		lRemoveCharacters.clear();
		text=applicar_regex(text,regular_expresion,remplazo,lRemoveCharacters);
			
		text = text.replaceAll("3 w es", "www");
		
		//por ejemplo 110% por un 10%
		text= text.replaceAll("1(\\d\\d)%","un $1%");
		
		text= text.replace("2 punto 0 DHA", "2.0 DHA");
		text= text.replace(" endesa ", " Endesa ");
		text= text.replace(" Endesa X ", " Endesa X ");
		text= text.replace(" Endesa energía ", " Endesa Energía ");
		
		//convertir  numero CUPS: por ejemplo es 00 4958 4455-3344- en ES00495844553344
		text= text.replace(" es 00", " ES00");
		text= text.replace(" e s 00", " ES00");
		text= text.replace(" ese 00", " ES00");
		regular_expresion = "((ES00)(([\\s]|-)?[0-9]+)*)";
		remplazo = "$1";
		lRemoveCharacters.add(" ");
		lRemoveCharacters.add("-");
		text=applicar_regex(text,regular_expresion,remplazo,lRemoveCharacters);
		    
	}
	
	private String applicar_regex(String texto,String regular_expresion, String remplazo, List<String>lRemoveCharacters)
	{
		Pattern p = Pattern.compile(regular_expresion);
		Matcher m = p.matcher(texto);
		String texto_return=texto;
		int disminucion_tamaño=0;
		
		while(m.find())
		{			
			int start= m.start()-disminucion_tamaño,end=texto_return.length()-(m.end()-disminucion_tamaño);
			String palabra=m.group().replaceAll(regular_expresion, remplazo);
		
			for(String removeCharacter: lRemoveCharacters)
			{
				palabra=palabra.replaceAll(removeCharacter,"");
			}			
			texto_return=texto_return.substring(0,start)+palabra+texto_return.substring(texto_return.length()-end,texto_return.length());
			disminucion_tamaño=texto.length()-texto_return.length();
		}
		return texto_return;		
	}
	
	public List<Entidad> getLista_entities() {
		return lista_entities;
	}

	public String getText() {
		return text;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getTextoFormateado() {
		return textoFormateado;
	}

	public void setTextoFormateado(String textoFormateado) {
		this.textoFormateado = textoFormateado;
	}

	public Long getSpeaker() {
		return speaker;
	}

	public float getInit() {
		return init;
	}

	public float getEnd() {
		return end;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	@Override
	public String toString() {
		return "<b>"+nombre+": </b> " + text ;
	}

}
