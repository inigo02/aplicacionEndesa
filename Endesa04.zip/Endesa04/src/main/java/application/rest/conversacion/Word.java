package application.rest.conversacion;

public class Word {
	String text;
	float init, end;
	public Word(String text, double init, double end)
	{
		this.text=text;
		this.end=(float)end;
		this.init=(float)init;
	}
	public String getText() {
		return text;
	}
	public float getInit() {
		return init;
	}
	public float getEnd() {
		return end;
	}
	
}
