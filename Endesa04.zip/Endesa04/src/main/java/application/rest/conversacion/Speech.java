package application.rest.conversacion;

import java.io.Serializable;

public class Speech implements Serializable{

	float init,end;
	Long speaker;
	public Speech( float init, float end, Long speaker)
	{
		this.init=init;
		this.speaker=speaker;
		this.end=end;
	}
	public float getInit() {
		return init;
	}
	public float getEnd() {
		return end;
	}
	public Long getSpeaker() {
		return speaker;
	}
	@Override
	public String toString() {
		return "Speech [init=" + init + ", end=" + end + ", speaker=" + speaker + "]";
	}
	
	
}
