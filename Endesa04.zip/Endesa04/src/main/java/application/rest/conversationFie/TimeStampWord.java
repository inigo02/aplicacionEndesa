package application.rest.conversationFie;

import java.io.Serializable;

public class TimeStampWord implements Serializable {

	double init;
	double end;
	String text;
	
	public TimeStampWord(String text, double init, double end)
	{
		this.text=text;
		this.init=init;
		this.end = end;
	}
	public double getStartTime() {
		return init;
	}
	public double getEndTime() {
		return end;
	}
	public String getWord() {
		return text;
	}
	
	
	

}
