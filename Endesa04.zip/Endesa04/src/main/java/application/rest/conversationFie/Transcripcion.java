package application.rest.conversationFie;

import java.io.Serializable;
import java.util.List;


public class Transcripcion implements Serializable{

	List<TimeStampWord> timeWords;
	String transcriptionWords;
	
	public Transcripcion(List<TimeStampWord> timeWords, String transcriptionWords) {
		this.timeWords=timeWords;
		this.transcriptionWords=transcriptionWords;
	}

	public List<TimeStampWord> getTimeWords() {
		return timeWords;
	}

	public String getTranscriptionWords() {
		return transcriptionWords;
	}
	
	

}
