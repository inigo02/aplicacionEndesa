package application.rest.conversationFie;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.ibm.watson.speech_to_text.v1.model.SpeechTimestamp;

import application.rest.conversacion.Conversation;
import application.rest.conversacion.Speech;
import application.rest.conversacion.Word;

public class FileConversation {

	List<Speech> speechList;
	List<Transcripcion> transcripciones;
	 List<Word>word_listAll;
	public List<Word> getWord_listAll() {
		return word_listAll;
	}

	TranscripcionSer transcripcionSer;
	/*
	 * SI SE SUBE UN FICHERO TXT
	 */
	public void obtenerConversacionTxt(String filename, List<Conversation>conversation_list) throws Exception{
		
		File file=new File(filename);
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
		    String line;
		    while ((line = br.readLine()) != null) {
		       conversation_list.add(new Conversation((long) 0,line,0,0));
		    }
		} catch (IOException e) {
			throw new Exception("Error al leer el fichero txt. "+e.getMessage());
		}
	}
	
	/*
	 * SI SE SUBE UN FICHERO SER
	 */
	
	public void formatearInformacionSer(String fileName) throws Exception
	{
		readTranscription(fileName);
		transcripciones = transcripcionSer.getTranscripciones();
   	  	speechList = transcripcionSer.getlSpeech();
   	  	getSpokenWords();
	}
	
	private List<Word> getSpokenWords() throws Exception
	{
	    word_listAll=new ArrayList<>();
	    
		for(Transcripcion result: transcripciones)
		{	
			List<String> wordsTranscript = getTranscriptedWords(result);
			List<TimeStampWord> timeStamps = result.getTimeWords();
			
			String transcriptText = result.getTranscriptionWords();
			String allTextTimeStamp = timeStamps.stream().map(TimeStampWord::getWord).collect(Collectors.joining(" "));
			
			
			List<Word> word_list=obtenerPalabras(timeStamps, wordsTranscript);
			
			word_listAll.addAll(word_list);
			imprimirIncorrectConvs(transcriptText, word_list, allTextTimeStamp);
		}
		return word_listAll;
	}
	
	private List<String> getTranscriptedWords(Transcripcion result)
	{
		String transcriptText = result.getTranscriptionWords().replace("  "," ");
		if(!transcriptText.equals(result.getTranscriptionWords()))
			System.out.println("### DIFERENTE  "+result.getTranscriptionWords());
		return new ArrayList<>(Arrays.asList(transcriptText.split(" ")));
	}
	
	private List<Word> obtenerPalabras(List<TimeStampWord> timeStamps, List<String> wordsTranscript) throws Exception{
		List<Word>word_list=new ArrayList<>();
		
		while(timeStamps.size()>0)
		{
			try {
				String text_timestamp = timeStamps.get(0).getWord(), text_transcript = wordsTranscript.get(0);	
				int nTranscriptWordsToDelete=0, nTimestampWordsToDelete=0;
				
				if(text_transcript.equals("4681"))
				{
					System.out.println("4681");
				}
				
				if(!text_transcript.equals(text_timestamp))
				{
					List<String>lWordsTimeStamps = getAllWordsTimeStamp(timeStamps);
				
					 if(containsWord(text_timestamp, text_transcript))
						nTranscriptWordsToDelete = findNumerOfContainingWords(text_timestamp, wordsTranscript);
					
					 else if(containsWord(text_transcript, text_timestamp ))
						 nTimestampWordsToDelete = findNumerOfContainingWords(text_transcript, lWordsTimeStamps);
					 
					 else if(isLastTranscriptWord(wordsTranscript, nTranscriptWordsToDelete))
					 	 nTimestampWordsToDelete=timeStamps.size()-1;
					 
					 else {
						 nTranscriptWordsToDelete = getallNumbers(wordsTranscript);
						 nTimestampWordsToDelete = getnumOfTimeStampWordsToDeletedWhenNumeric(timeStamps, wordsTranscript, nTranscriptWordsToDelete);
					 }
				}
				Word word = createWord(timeStamps, nTimestampWordsToDelete, wordsTranscript,nTranscriptWordsToDelete);
				word_list.add(word);
				deleteWords(timeStamps, nTimestampWordsToDelete, wordsTranscript,nTranscriptWordsToDelete);
			}catch (Exception e) {
				throw new Exception("Problemas al obtener palabras del SpeechRecognitionResults. "+e.getMessage());
			}	
		}
		
		return word_list;
	}
	
	private int getnumOfTimeStampWordsToDeletedWhenNumeric(List<TimeStampWord> timeStamps, List<String> wordsTranscript, int nTranscriptWordsToDelete )
	{
		List<String>lWordsTimeStamps = getAllWordsTimeStamp(timeStamps);
		int nTimestampWordsToDelete = isLastTranscriptWord(wordsTranscript,nTranscriptWordsToDelete)?
				 timeStamps.size()-1 : findNextNoNumericTimeStampWord(wordsTranscript, nTranscriptWordsToDelete+1, lWordsTimeStamps);
		return nTimestampWordsToDelete;
	}
	
	private Word createWord(List<TimeStampWord> timeStamps, int nTimestampWordsToDelete, List<String> wordsTranscript,
			int nTranscriptWordsToDelete) {
		Word word =null;
		String text_transcript = getTranscriptWord(wordsTranscript, nTranscriptWordsToDelete);
		double init= timeStamps.get(0).getStartTime();
		double end=timeStamps.get(nTimestampWordsToDelete).getEndTime();
		 word = new Word(text_transcript, init, end);
		return word;
	}
	
	private List<String> getAllWordsTimeStamp(List<TimeStampWord> timeStamps)
	{
		return timeStamps.stream().map(TimeStampWord::getWord).collect(Collectors.toList());
	}
	
	private void deleteWords(List<TimeStampWord> timeStamps, int nOfTimestampWordsToDelete,
			List<String> wordsTranscript, int nOfTranscriptWordsToDelete) {
		
		for(int i=0; i<=nOfTranscriptWordsToDelete; i++)
			 wordsTranscript.remove(0);
		
		for(int i=0; i<=nOfTimestampWordsToDelete; i++)
			timeStamps.remove(0);		
	}

	private boolean containsWord(String word1,String word2) {
		word1=formatWord(word1);
		word2=formatWord(word2);
		return word1.startsWith(word2);
	}
	
	private String formatWord(String word){
		return word.replace(",", "coma").replace(".", "punto").replace("guión", "-");
	}
	
	private int findNumerOfContainingWords( String wordContainer, List<String> lContainedWords) {
		int numOfContainedWords;
		wordContainer=formatWord(wordContainer);
		for(numOfContainedWords=0; numOfContainedWords<lContainedWords.size();numOfContainedWords++)
		{
			String containedWord = lContainedWords.get(numOfContainedWords);
			String formattedContainedWord = formatWord(containedWord);
			if(!wordContainer.startsWith(formattedContainedWord))
				break;
			wordContainer=wordContainer.replace(formattedContainedWord, "");
		}	
		numOfContainedWords--;
		return numOfContainedWords;
	}
	
	private int findNextNoNumericTimeStampWord( List<String> wordsTranscript, int indexNextWordTranscript, List<String> lContainedWords) {
		String nextWordTranscript = wordsTranscript.get(indexNextWordTranscript);
		int numOfContainedWords;
		String transtcript_words="";
		for (int i=0;i<indexNextWordTranscript;i++)
			transtcript_words+=wordsTranscript.get(i);
		transtcript_words= formatWord(transtcript_words);
		for(numOfContainedWords=1; numOfContainedWords<lContainedWords.size();numOfContainedWords++)
		{
			String containedWord = lContainedWords.get(numOfContainedWords);
			String formattedContainedWord=containedWord;
			
			if(transtcript_words.contains(formattedContainedWord))
			{
				transtcript_words=transtcript_words.replace(transtcript_words,"");
				continue;
			}
			
			if((nextWordTranscript.startsWith(formattedContainedWord) || formattedContainedWord.startsWith(nextWordTranscript)) && formattedContainedWord.length()>2)
				break;
		}	
		numOfContainedWords--;
		return numOfContainedWords;
	}
	
	private boolean isLastTranscriptWord(List<String> wordsTranscript, int actualIndex) {
		return wordsTranscript.size()==actualIndex+1;
	}
	
	private boolean isWordANumber(String strNum) {
	    try {
	    	strNum = strNum.replace(",", ".");
	    	strNum = strNum.replace("€", "");
	    	strNum = strNum.replace(":", "");
	    	strNum = strNum.replace("/", "");
	    	strNum = strNum.replace("%", "");
	    	strNum = strNum.replace("-", "");
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}

	private int getallNumbers(List<String> wordsTranscript) {
		int kont=1;
		for (int i=1; i<wordsTranscript.size();i++)
		{
			String word= wordsTranscript.get(i);
			if(!isWordANumber(word) && word.length()>2 )
			{
				if(word.contains(","))
				{
					kont++;
					continue;
				}
				break;
			}
			kont++;
		}
		if(kont+1<wordsTranscript.size())
			kont =  wordsTranscript.get(kont).equals("punto") && wordsTranscript.get(kont+1).equals("5")? kont+2 : kont;
		kont--;
		return kont;
	}
	
	private String getTranscriptWord(List<String> wordsTranscript, int transcriptPassedWords) {
		String text="";
		for(int i=0;i<=transcriptPassedWords;i++)
		{
			text += wordsTranscript.get(i)+" ";
		}
		text= text.substring(0, text.length() - 1);
		return text;
	}
		
	private void readTranscription (String fileName) throws Exception
	{
		try{
		      InputStream file = new FileInputStream(fileName);
		      InputStream buffer = new BufferedInputStream(file);
		      ObjectInput input = new ObjectInputStream (buffer);
		      try{
		    	  this.transcripcionSer = (TranscripcionSer)input.readObject();
		    	 
		      }finally{
		        input.close();
		      }
		    }catch(ClassNotFoundException ex){
		    	throw new Exception("Cannot perform input. Class not found."+ ex);
		    }catch(IOException ex){
		    	throw new Exception("Cannot perform input."+ ex);
		    }
	}

	public List<Speech> getSpeechList() {
		return speechList;
	}

	public List<Transcripcion> getTranscripciones() {
		return transcripciones;
	}
	
	private void imprimirIncorrectConvs(String transcriptText, List<Word> word_list, String allTextTimeStamp ) {		
		String wordsCreated = word_list.stream().map(Word::getText).collect(Collectors.joining(" "));
		List<String> wordsTranscript = new ArrayList<>(Arrays.asList(transcriptText.split(" ")));
		String textTranscript = wordsTranscript.stream().collect(Collectors.joining(" "));
		if(!wordsCreated.equals(textTranscript))
		 {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("timeStamp :    "+allTextTimeStamp);
			System.out.println("transcript:    "+textTranscript);
			System.out.println("words created: "+wordsCreated);
			System.out.println("----------------------------------");
			System.out.println();
		 }
		
	}
		
}
