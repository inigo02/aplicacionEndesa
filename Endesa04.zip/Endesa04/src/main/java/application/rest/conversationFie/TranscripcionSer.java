package application.rest.conversationFie;

import java.io.Serializable;
import java.util.List;

import application.rest.conversacion.Speech;

public class TranscripcionSer implements Serializable {
	
	List<Transcripcion> transcripciones;
	List<Speech> lSpeech;
	
	public TranscripcionSer(List<Transcripcion> transcripciones, List<Speech> lSpeech)
	{
		this.transcripciones = transcripciones;
		this.lSpeech = lSpeech;
	}

	public List<Transcripcion> getTranscripciones() {
		return transcripciones;
	}

	public List<Speech> getlSpeech() {
		return lSpeech;
	}

}
