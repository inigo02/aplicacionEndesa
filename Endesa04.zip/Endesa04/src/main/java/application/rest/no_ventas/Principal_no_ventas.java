package application.rest.no_ventas;


import java.io.FileNotFoundException;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
public class Principal_no_ventas {
	
	
	@RequestMapping(value = "/transcribir_no_ventas")
	@ResponseBody
	 public String main(@RequestParam("archivo_audio") MultipartFile multipart[],String[] args) throws FileNotFoundException {	

		String resultado= "En proceso de desarrollo, prueba con los audios de no ventas.";

  
	    return resultado;		
		}

	
	
}
