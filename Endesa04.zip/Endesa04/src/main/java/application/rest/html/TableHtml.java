package application.rest.html;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.ibm.watson.natural_language_understanding.v1.model.DocumentSentimentResults;
import com.ibm.watson.natural_language_understanding.v1.model.EntitiesResult;

import textAnalysis.KnowledgeStudio_ventas;

public class TableHtml {
	
	KnowledgeStudio_ventas knStudio;

	public TableHtml(KnowledgeStudio_ventas knStudio) {
		this.knStudio=knStudio;
	}
	
	public String createInfoTable() {
		
		List<EntitiesResult> lEntities = knStudio.getlEntities();
		
		List<String[]> leftTableVals = getLeftTableValues(lEntities);
		String leftTableHtml=createHtmlTable(leftTableVals, "Datos de la conversación","green");
		
		
		List<String[]> rightTableVals= getRightTableValues(lEntities);
		String rightTableHtml=createHtmlTable(rightTableVals,"Analísis de la conversación","blue");
		
		String tabla_entidades = createTable(leftTableHtml, rightTableHtml);
		return tabla_entidades;
	}
	
	private String createTable(String leftTableHtml, String rightTableHtml) {
		String tabla_entidades = "<div class='tablageneral'> <div class='tablaizq'>"
				+ leftTableHtml
				+ "</div><div class='tablader'>"
				+ rightTableHtml + "</div></div>";
		return tabla_entidades;
	}

	private List<String[]> getRightTableValues(List<EntitiesResult> lEntities) {
		List<String[]> rightTableVals = new ArrayList<String[]>();
		boolean isLeftTable=false;
		
		String cumplimiento_politica_endesa=getSpecificEntityValues(lEntities,"POLITICA_ENDESA",isLeftTable);
    	String cumplimiento_protocolo_preguntas= getSpecificEntityValues(lEntities,"PROTOCOLO_PREGUNTAS",isLeftTable);
		String cumplimiento_protocolo_competencia= getSpecificEntityValues(lEntities,"PROTOCOLO_COMPETENCIA",isLeftTable);
		String cumplimiento_despedida_endesa= getSpecificEntityValues(lEntities,"DESPEDIDA_ENDESA",isLeftTable);
		
		rightTableVals.addAll(getSentimentValuesHtml());
		rightTableVals.add(getArray("Politica endesa", cumplimiento_politica_endesa));
    	rightTableVals.add(getArray("Protocolo preguntas", cumplimiento_protocolo_preguntas));
    	rightTableVals.add(getArray("Protocolo competencia", cumplimiento_protocolo_competencia));
    	rightTableVals.add(getArray("Despedida Endesa", cumplimiento_despedida_endesa));
    	
		return rightTableVals;
	}

	private List<String[]> getLeftTableValues(List<EntitiesResult> lEntities) {
		
		boolean isLeftTable=true;
		String calle= getSpecificEntityValues(lEntities, "CALLE",isLeftTable);
		String DNI= getSpecificEntityValues(lEntities, "DNI",isLeftTable);
		String correo= getSpecificEntityValues(lEntities, "CORREO_ELECTRONICO",isLeftTable);
		String telefono= getSpecificEntityValues(lEntities, "NUMERO_MOVIL",isLeftTable);
		String cups = getSpecificEntityValues(lEntities, "CODIGO_CUPS",isLeftTable);
		String agente = getPersonEntiyName(lEntities, "Agente");
		String titular = getPersonEntiyName(lEntities, "Titular");
		
		List<String[]> leftTableVals = new ArrayList<String[]>();		
		leftTableVals.add(getArray("Agente", agente));
		leftTableVals.add(getArray("Titular", titular));
		leftTableVals.add(getArray("Dirección del titular", calle));
		leftTableVals.add(getArray("DNI del titular", DNI));
		leftTableVals.add(getArray("Número movil del titular", telefono));
		leftTableVals.add(getArray("Correo electronico del titular", correo));
		leftTableVals.add(getArray("Codigo CUPS", cups));
    	
		return leftTableVals;
	}

	private String[] getArray(String name, String value){
		return new String[]{name, value};
	}

	private String createHtmlTable( List<String[]> tableVals, String tableTitle, String tableColor)
	{
		String result = "<table class='table'>"
				+"<tbody>"
				+"<tr class='row "+tableColor+"'><th colspan='2'><h3>"+tableTitle+"</h3></th></tr>";
	
		 for (String val[] : tableVals) {
			 result += insertarFilaHtml(val[0],val[1]);
		 }
		result+="</tbody></table>";
		return result;
	}
	
	private String insertarFilaHtml(String title, String val){
		return "<tr class='row'><th>" + title + "</th><td>" + val + "</td></tr>";
	}
	
	private String getPersonEntiyName(List<EntitiesResult> entities, String subtype) {
		List<String> persona=entities.stream().filter(e-> e.getType().equals("PERSONA") && e.getDisambiguation().getSubtype().contains(subtype)).map(EntitiesResult::getText).collect(Collectors.toList());
		eliminar_repetidos(persona);
		String result = persona.stream().collect(Collectors.joining(","));
		return result;
	}

	private String getSpecificEntityValues(List<EntitiesResult> entities, String entityType, boolean leftTable)
	{
		List<String> lresults= entities.stream().filter(e-> e.getType().equals(entityType)).map(EntitiesResult::getText).collect(Collectors.toList());
		String result;
		if(leftTable) {
			lresults=eliminar_repetidos(lresults);
			result = lresults.stream().collect(Collectors.joining(","));
		}
		else{
			result=verificarCumplimientoProtocolo(lresults);
			result = "<img src=\'"+result+"\'alt=\'\' border=3 height=25 width=25></img>";
		}
		return result;
	}
	
	private String verificarCumplimientoProtocolo(List<String> resultados)
	{
		String img=resultados.isEmpty()?"incorrect.jpg":resultados==null?"in.jpg":"correct.jpg";
		return "Imagenes/Analisis_audio/"+img;
	}
	
	private List<String> eliminar_repetidos(List<String>lista)
	{
		return lista.stream().distinct().collect(Collectors.toList());
	}
	
	private List<String[]> getSentimentValuesHtml()
	{
		List<String[]> rightTableVals = new ArrayList<String[]>();		
		Map<String, DocumentSentimentResults> mapSentimientos= knStudio.getMapSentimientos();
		
		DocumentSentimentResults sentimentAgente=mapSentimientos.get("agente");
		String[] resultado = getSentiment(sentimentAgente,"agente");
		rightTableVals.add(resultado);
		
		DocumentSentimentResults sentimentTitular=mapSentimientos.get("titular");
		resultado = getSentiment(sentimentTitular,"cliente");
		rightTableVals.add(resultado);
		
		DocumentSentimentResults sentimentTotal=mapSentimientos.get("total");
		resultado = getSentiment(sentimentTotal,"total");
		rightTableVals.add(resultado);
		
		 return rightTableVals;
	}
	
	private String[] getSentiment(DocumentSentimentResults sentiment, String speakerName)
	{
		String sentimentVal=sentiment.getLabel()+" ("+sentiment.getScore()+")";
		String[] resultado=getArray("Sentimiento "+speakerName, sentimentVal);
		return resultado;		
	}
	
}
