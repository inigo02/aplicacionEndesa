package application.rest.html;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.ibm.watson.natural_language_understanding.v1.model.EntitiesResult;

import application.rest.conversacion.Conversation;
import textAnalysis.Entidad;
import textAnalysis.KnowledgeStudio_ventas;

public class BodyHtml {
	
	Map<String, String> colorEntidades;
	List<Conversation> lConversaciones;
	List<EntitiesResult> lEntities;
	
	public BodyHtml(KnowledgeStudio_ventas knStudio)
	{
		mapEntities();
		lEntities=knStudio.getlEntities();
		lConversaciones=knStudio.getlConversaciones();
	}
	
	public String getHtmlText()	{
		String entidadesHTML = get_Html_list_of_identified_entities();
		String conversationText="";
		for( Conversation c: lConversaciones)
		{
			colorearEntidades(c);
			conversationText += " "+getConversationHtml(c);
		}
		String result = "<div id='divAnalisis'><div id='listatranscribir'>"+entidadesHTML +"</div><div id='transcriptAudio'><b><center>Transcripción:</center></b>"+"<br>"+conversationText+"</div></div>";
		return result;
	}
	
	public String getCabecera()
	{
		String cabecera=  "<div class='cabecera'>"
				+ "     <div class='logo'>Audio analizado</div>"
				+ "     <nav class='opciones'>"
				+ "       	<a class='referencia' id='rtranscripcion' onclick=\"analizarResultado('Transcripcion')\" href='#'>Transcripcion</a>"
				+ "	  		<a class='referencia' id='rresultados' onclick=\"analizarResultado('Resultados')\" href='#'>Resultados</a>"
				+ "      	<a class='referencia' id='ranalisis' onclick=\"analizarResultado('Transcripcion analizada')\" href='#'>Transcripcion analizada</a>"
				+ "			<a class='referencia' id='ranalisis' onclick=\"analizarResultado('Subir fichero')\" href='#'>Nueva transcripcion</a>"
				+"		</nav>"
				+ "</div>";
		return cabecera;
	}

	public void colorearEntidades(Conversation c) {
		List<Entidad>converEntities = c.getLista_entities();
		Collections.sort(converEntities);
		String texto=c.getText();
		for (Entidad e:converEntities)
		{
			String color=colorEntidades.get(e.getEntidad().getType());
			int startPos=e.getInit(),endPos=e.getEnd();
        	texto=getEntityColoredText(texto, startPos, endPos, color);
		}
		c.setTextoFormateado(texto);
	}
	
	public String getEntityColoredText(String texto, int startPos, int endPos, String color)
	{
		String html_color="<span style=\'background-color:"+color+";\'>"+texto.substring( startPos, endPos)+"</span>";
		texto= texto.substring(0,startPos)+html_color+texto.substring(endPos,texto.length());
		return texto;
	}
	
	private String get_Html_list_of_identified_entities() {
		HashSet<String> lEntidadesTotales= getIdentifiedEntities();
		String lEntidades="";
		for(String e:lEntidadesTotales)
		{
			String colorEntity=colorEntidades.get(e);
			lEntidades+="<li><span style=\'background-color:"+colorEntity+";\'>"+e+"</span></li>";
		}
		String HtmlEntities="<b> Entidades:</b> <br><ol>"+lEntidades+"</ol>";
		return HtmlEntities;
	}
		
	private HashSet<String> getIdentifiedEntities() {
		return new HashSet<>(lEntities.stream().map(EntitiesResult::getType).collect(Collectors.toList()));
	}
	
	public void mapEntities()
	{
		colorEntidades = new HashMap<String, String>();
		colorEntidades.put("SALUDO", "#FF6633"); 
		colorEntidades.put("AGRADECIMIENTO", "#FFB399");
		colorEntidades.put("DESPEDIDA", "#FF33FF");
		colorEntidades.put("PERSONA", "#FFFF99");
		colorEntidades.put("ORGANIZACION", "#00B3E6");
		colorEntidades.put("CALLE", "#E6B333");
		colorEntidades.put("CORREO_ELECTRONICO", "#CCCC00");
		colorEntidades.put("PROTOCOLO_PREGUNTAS", "#66E64D");
		colorEntidades.put("PROTOCOLO_COMPETENCIA", "#4D80CC");
		colorEntidades.put("NUMERO_MOVIL", "#9900B3");
		colorEntidades.put("CODIGO_CUPS", "#E64D66");
		colorEntidades.put("DNI", "#4DB380");
		colorEntidades.put("TARIFA", "#FF4D4D");
		colorEntidades.put("DESPEDIDA_ENDESA", "#99E6E6");
		colorEntidades.put("POLITICA_ENDESA", "#6666FF");
		colorEntidades.put("BIENVENIDA", "#00E680");
		colorEntidades.put("SERVICIO", "#1AFF33");
	}

	public String getConversationHtml(Conversation c)
	{
		
    	String texto = "<b>"+c.getNombre()+": </b> " + c.getTextoFormateado()+" "+reproductor_audio_HTML(c)+" <br>"; 
    	
		return texto;
	}
    
	public String reproductor_audio_HTML(Conversation c){
		
		String speechStartSecond=String.valueOf(c.getInit());
		speechStartSecond=speechStartSecond.equals("0.0")?"0":speechStartSecond;
		String SpeechEndSecond=String.valueOf(c.getEnd());
		
		String buttonid="id=\'btn_audio_"+speechStartSecond;
		String buttonTag = "<button onclick=\"myFunction("+speechStartSecond+","+SpeechEndSecond+",'')\" " + buttonid + "\'> ";
		String buttonImgTag = "<img src=\'Imagenes/Analisis_audio/play.png\' height=\'15\' width=\'15\'>";
		String respuesta= buttonTag+ buttonImgTag+ " </button>";
		
		return respuesta;
		
	}

	public Map<String, String> getColorEntidades() {
		return colorEntidades;
	}
		
	public String crearChat(String nombreArchivo)
	{
		String respuesta = "<br> 	<section class=\'chat-main\'>"
				+ "		<div class=\'chat-fileName\'>"
				+ "		"+nombreArchivo
				+ "		</div>"
				+ "		<section class=\'chatbox\'>";
		for(Conversation c:lConversaciones)
		{
			respuesta += crearChatSpeech(c);
		}
		respuesta += "</section></section>";
		return respuesta;
	}
	public String crearChatSpeech(Conversation c)
	{
		String nombre = c.getNombre().toLowerCase();
		String text = c.getText().substring(0, 1).toUpperCase() + c.getText().substring(1);;
		String tiempo = obtenerTiempo(c.getEnd());
		String tipo = nombre.equals("agente")?"msg-self":"msg-remote";
		
		String respuesta= "		<article class=\'msg-container "+tipo+"\'>"
				+ "			<div class=\'msg-box\'>"
				+ "				<img class=\'user-img "+nombre+"\' />"
				+ "				<div class=\'flr\'>"
				+ "					<div class=\'messages\'>"
				+ "						<p class=\'msg\' >"
				+ "						"+text	
				+ "						</p>"
				+ "					</div>"
				+ "					<span class=\'timestamp\'><span class=\'username\'>"+nombre+"</span>&bull;<span class=\'posttime\'>"+tiempo+" </span></span>"
				+ "				</div>"
				+ "			</div>"
				+ "		</article>";
		
		return respuesta;
	}

	private String obtenerTiempo(float seconds) {
		int sec = Math.round(seconds);
		String respuesta = String.format("%02d:%02d:%02d",(sec/3600), ((sec % 3600)/60), (sec % 60));
	    return respuesta;
		
	}
}
