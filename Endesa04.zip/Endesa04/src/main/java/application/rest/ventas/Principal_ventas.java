package application.rest.ventas;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import application.rest.conversacion.Lista_conversaciones;
import application.rest.html.BodyHtml;
import application.rest.html.TableHtml;
import textAnalysis.KnowledgeStudio_ventas;


@RestController
public class Principal_ventas {
	
	Lista_conversaciones lista_conversaciones;
	final String api_key_stt, url_stt, customizationId, languageCustomizationId, NLU_apikey, NLU_url_key, KnowledgeStudiomodelID;
	KnowledgeStudio_ventas knowledgeStudio;
	String nombre_archivo;
		
	@RequestMapping(value = "/transcribir_ventas")
	@ResponseBody
	 public String main(@RequestParam("archivo_audio") MultipartFile multipart[],String[] args) throws FileNotFoundException {	
		Principal_ventas app=new Principal_ventas();
		String watson_respuesta[];
		try {
			watson_respuesta = app.ejecutar_aplicacion(multipart);
		} catch (Exception e) {
		
			return e.getMessage();
		}	   
	    String respuesta = watson_respuesta[0]+"##--##"+watson_respuesta[1]+"##--##"+watson_respuesta[2];
		return respuesta;		
	}

	public Principal_ventas() {
		//Speach to text
		api_key_stt= "8uEzw_abjE73cc8IphYwDV6rXaHPHDZZqKv9jM1ZqX6u";
		 url_stt= "https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/39be799b-08e9-43f3-9269-71a23bc7cbf1";    	
		customizationId="b0f854a1-b52c-468f-9707-3e94b4079073";
    	languageCustomizationId="11b90cdf-ab20-4ed3-a7ff-c54e43c23f49";

    	//Natural Language Understanding y Knowledge studio
    	NLU_apikey="tJ5kaefm3zoBX_iDnG_Epvt6L7oeYu6gfMgRk_EMLIyc";
    	NLU_url_key="https://api.eu-gb.natural-language-understanding.watson.cloud.ibm.com/instances/46bec363-29a2-4c78-b557-248396b28757";
    	KnowledgeStudiomodelID="76b1519d-5bbd-42ab-87f8-30be571f840a";
    	
    	}
	
	private String[] ejecutar_aplicacion(MultipartFile[] multipart) throws Exception
	{
		String[] resultado_analisis = null;
		List<String> archivos_a_transcribir=getFile(multipart);
		for (String archivo_a_transcribir:archivos_a_transcribir)
		{
			transcribir_conversacion(archivo_a_transcribir);
			busqueda_entidades();
			resultado_analisis= getHtmlResults();
		
		}
		return resultado_analisis;
	}
	    
	private void transcribir_conversacion(String archivo_a_transcribir) throws Exception
	{
		lista_conversaciones=new Lista_conversaciones(api_key_stt, url_stt, customizationId, languageCustomizationId);
		lista_conversaciones.transcribir_audio(archivo_a_transcribir);	
	}
	
	private void busqueda_entidades()
	{
		knowledgeStudio= new KnowledgeStudio_ventas(NLU_apikey, NLU_url_key, KnowledgeStudiomodelID, lista_conversaciones);
		knowledgeStudio.findEntitiesInTranscription();
	}
	
	private String[] getHtmlResults()
	{

		TableHtml table = new TableHtml(knowledgeStudio);
		BodyHtml body = new BodyHtml(knowledgeStudio);
		String tableHTML = table.createInfoTable();
		String bodyHTML= body.getHtmlText();
		
		String cabecera= body.getCabecera();
		
		String resultTranscripcion = body.crearChat(nombre_archivo);
		String results[] = new String[] { 
				cabecera+resultTranscripcion, cabecera+tableHTML, cabecera+bodyHTML};
		return results;
	}	
	
	
	private List<String> getFile( MultipartFile multipart[])
	{
		String timeStamp = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		String archivo_a_transcribir = null;
	    String uploadPath = "src/main/resources/public/upload/";
		//String uploadPath = "/home/vcap/app/BOOT-INF/classes/public/upload";
		File uploadDir = new File(uploadPath);
		System.out.println(timeStamp + " uploadDir: " + uploadDir); 
		
		if (!uploadDir.exists()) {
			uploadDir.mkdir();
		}
		List <String> archivos_a_transcribir= new ArrayList<>();
		for (MultipartFile file : multipart){
			if (file.isEmpty()) {
				System.out.println(timeStamp + " Error: Archivo vacío");
			}
			try {
				String fileName = file.getOriginalFilename();
				System.out.println("fileName: " +fileName);
				InputStream is = file.getInputStream();
				archivo_a_transcribir = uploadPath + fileName;
				archivos_a_transcribir.add(archivo_a_transcribir);
				nombre_archivo=fileName;
				Files.copy(is, Paths.get(archivo_a_transcribir),
						StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				System.out.println(timeStamp + " Error: No ha sido posible copiar el archivo -> " + file.getName());
			}
		}    
        return archivos_a_transcribir;
	}
	
}
