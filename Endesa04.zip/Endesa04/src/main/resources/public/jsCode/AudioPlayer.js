
var audio=null;
var init=-1;
var fin=-1;
var empezar=true;
function myFunction(start,end,file_name) 
{
	console.log("ni audio playing");
	if(file_name!="")
	{
		audio = document.createElement("audio");
		audio.src ="upload/"+file_name;
		init=-1;
		fin=-1;
		empezar=true;
		audio.currentTime=0;
		this.audio.addEventListener('timeupdate', function() 
		{
			t = this.currentTime;
			if (t >fin) {
				this.pause();
				this.currentTime=0;
				document.getElementById("btn_audio_"+init).innerHTML = '<img src="Imagenes/Analisis_audio/play.png" height="15" width="15">';
				init=-1;
			}
		});
	}
	
	else
	{
		console.log("Sartu da botoian "+audio.currentTime)
		if(init!=start)
		{
			audio.currentTime=start;
			if(empezar){
				empezar=false;
				}
			else{
				document.getElementById("btn_audio_"+init).innerHTML = '<img src="Imagenes/Analisis_audio/play.png" height="15" width="15">';
				audio.pause();
				}		
		}
		init=start;
		fin=end;
		var button = document.getElementById("boton_audio_"+init);
		var playing= !audio.paused;
		if(playing){
			console.log("pause");

			audio.pause();
			document.getElementById("btn_audio_"+init).innerHTML = '<img src="Imagenes/Analisis_audio/play.png" height="15" width="15">';
		}
		else{
			console.log("play");
			audio.play();
			document.getElementById("btn_audio_"+init).innerHTML = '<img src="Imagenes/Analisis_audio/pause.png" height="15" width="15">';
		}		
	}			
}
	
	
