
    	function transcribir_audio(){
    		archivo_audio = $('#audiofile').prop('files')[0];
			document.getElementById('transcript').innerHTML=('Subiendo ' + document.querySelector('#audiofile').files[0].name + '...');
    		
    		var form_data = new FormData();                  
    		form_data.append('archivo_audio', archivo_audio);
    		
    		document.getElementById('transcript').innerHTML=('Transcribiendo ...');
    		
    		var response = document.querySelector('input[name="filetype"]:checked').value;
    		
    				
    		if(response=="No ventas")
    		{
					response = "/transcribir_no_ventas";
			}
			else{
					response = "/transcribir_ventas";
			}
			console.log(response);
    		$.ajax({
	
    			url: response, 
    			dataType: 'text',  
    			cache: false,
    			contentType: false,
    			processData: false,
    			data: form_data,                         
    			type: 'post',
    			success: function(java_script_response){
    				document.getElementById('transcript').innerHTML = "";
    				var resultados = java_script_response.split("##--##");
    				document.getElementById('transcript').innerHTML = resultados[0];
    				
    				myFunction(0,0,document.querySelector('#audiofile').files[0].name);
    				analizarResultado(resultados[0],resultados[1], resultados[2]);
    				
    				
    			}
    		 });
    	}        

        