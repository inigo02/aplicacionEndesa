
	var transcripcion="";
	var resultados="";
	var analisis="";
	var subirFichero="";
	function analizarResultado(res1="",res2="", res3="") 
	{ 
		let transcript = document.querySelector('#transcript');
		if(transcripcion=="")
		{
			
			transcripcion=res1;
			resultados=res2;
			analisis=res3;
			subirFichero=document.querySelector('#cargarArchivo').outerHTML;
			document.querySelector('#cargarArchivo').innerHTML ="";
			transcript.innerHTML = transcripcion;
			
			document.querySelector("#rtranscripcion").style.backgroundColor='#056464';
			
		}
		else{
			let itemsCabecera = ["#rtranscripcion", "#rresultados","#ranalisis","#ranalisis"];
			itemsCabecera.forEach((i) => {
			    document.querySelector(i).style.backgroundColor="transparent";
			});
			let itemCabeceraSelected = "";
			

			switch(res1)
			{
				case "Transcripcion":
					transcript.innerHTML = transcripcion;
					itemCabeceraSelected = itemsCabecera[0];
				break;
				case "Resultados":
					transcript.innerHTML = resultados;
					itemCabeceraSelected = itemsCabecera[1];
					console.log(itemCabeceraSelected);
				break;
				case "Transcripcion analizada":
					transcript.innerHTML = analisis;
					itemCabeceraSelected = itemsCabecera[2];
				break;
				case "Subir fichero":
				document.querySelector('#cargarArchivo').innerHTML=subirFichero;
				transcript.innerHTML = "<center>El resultado de la transcripción se mostrará aquí.</center>";
				transcripcion="";
				resultados="";
				analisis="";
				return;	
				
			}
			
			document.querySelector(itemCabeceraSelected).style.backgroundColor='#056464';
				
		} 
		
		
	}
